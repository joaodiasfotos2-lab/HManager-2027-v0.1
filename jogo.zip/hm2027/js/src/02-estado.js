  // ============================= 02-estado.js =============================
  // Estado global do jogo
  // Global state
  // =================================================================
  const state = {
    teams: {}, userTeamId: null, season: 1, seasonOver:false,
    // Diagnóstico de fecho de época preso (ver globalSeasonCloseBlockers, 07-playoff.js):
    // seasonOverSinceDate marca desde quando seasonOver está true; seasonCloseStuckWarned
    // garante que o aviso de "época bloqueada" só é publicado uma vez por bloqueio.
    seasonOverSinceDate: null, seasonCloseStuckWarned: false,
    match: null, speedMs: 180, timer: null, importTargetId: null,
    pendingFixture: null, convocados: [], convocadosSelecionados: null,
    pendingSuspensionServing: null,
    activeView: "clube", previousView: "clube", currentDate: null, news: [],
    // Histórico de navegação para o botão "← Voltar" (pedido do utilizador: "quero um botão de
    // voltar atrás para poder navegar mais naturalmente no jogo"). Ver setView/goBackView em
    // 01-nucleo.js — nunca inclui a vista "jogo" (entrar/sair de uma partida não deve poder ser
    // alvo de "voltar") e não precisa de persistir no save (é só conveniência da sessão atual).
    viewHistory: [],
    managerName: "", playoffActive: false, pendingPlayoffSeries: null, playoffClinchedAnnounced: false, pendingProvisional: null, pendingPostMatchCtx: null,
    // Fase 1 da 2ª Divisão: state.competitions passa a ser a única fonte de verdade sobre
    // calendário/jornada/playoff. fixtures, currentRound e playoff ficam definidos mais abaixo
    // como propriedades de acesso (getter/setter) que apontam sempre para a competição atual do
    // utilizador (hoje só existe o Placard) — o resto do código não muda nada, continua a ler e
    // escrever state.fixtures/state.currentRound/state.playoff exatamente como sempre fez.
    competitions: {}, userCompetitionId: null, viewedCompetitionId: null,
    // Ficha do Clube como página inteira (Fase 6 da Academia e Juvenis, 2026-09-22): mesmo padrão
    // de viewedCompetitionId/openCompetitionView, mas para o clube em vista em setView("ficha")
    // (openClubFicha, 05-ui-navegacao.js) — substitui o antigo modal openClubModal/clubModal.
    viewedFichaTeamId: null,
    lastLoadedSaveVersion: null, diagnosticsReport: null, validationHistory: [], saveGrowthAudit: null, calibrationValidationReport: null, calibrationValidationHistory: [],
    globalAgenda: [], pendingAgendaEventId: null,
    promotionTie: null, pendingPromotionTieGameIndex: null,
    // Final da 2ª Divisão (1.º do Norte vs. 1.º do Sul) — sem promoção associada, só prestígio.
    secondDivisionFinal: null, pendingSecondDivisionFinalGameIndex: null,
    // Taça de Portugal — eliminação direta, todas as divisões, iniciada e sorteada de raiz no
    // arranque de cada época (ver 07b-taca-portugal.js).
    tacaPortugal: null, pendingTacaPortugalFase: null, pendingTacaPortugalIndex: null,
    // Supertaça António Livramento — jogo único de pré-época, em campo neutro, entre o campeão
    // nacional e o vencedor da Taça de Portugal (ou o finalista, se o mesmo clube venceu as duas
    // provas); ver 07c-supertaca.js. { historico:[...edições passadas], jogo: edição corrente }.
    supertaca: null, pendingSupertaca: false, preSeason: null, arbitros: null, analise: null, satelites: null, calAmig: null, lesoes: null, relB: null, pendingAmigavel: false,
    // Elite Cup — eliminatória de pré-época a uma mão, campo neutro, entre os 8 primeiros
    // classificados do Campeonato Placard da época anterior (ver 07d-elite-cup.js).
    // { historico:[...edições passadas], edicao: edição corrente ou null }.
    eliteCup: null, pendingEliteCupFase: null, pendingEliteCupIndex: null,
    // Guarda, enquanto a Elite Cup ainda não terminou, o que fazer a seguir (abrir a pré-época
    // de mercado da 1.ª carreira, ou concluir a transição para a nova época) — ver
    // eliteCupRunPostSequence em 07d-elite-cup.js.
    eliteCupPostSequence: null,
    // Copa del Rey (Espanha) e Coppa Italia — Final a Oito/quartos+Final Four a meio da época,
    // apuramento pelos 8 primeiros da 1ª volta da OK Liga/Serie A1 (ver 07e-copas-nacionais.js).
    // { historico:[...edições passadas], edicao: edição corrente ou null }.
    copaDelRey: null, pendingCopaDelReyFase: null, pendingCopaDelReyIndex: null,
    coppaItalia: null, pendingCoppaItaliaFase: null, pendingCoppaItaliaIndex: null,
    // Supercopa de España (Final Four de pré-época, 4 clubes fixos) e Supercoppa Italiana (2
    // clubes, eliminatória a duas mãos, meados da época) — ver 07f-supertacas-internacionais.js.
    supercopaEspana: null, pendingSupercopaEspanaFase: null, pendingSupercopaEspanaIndex: null,
    supercoppaItaliana: null, pendingSupercoppaItalianaLeg: null,
    // Competições Europeias (WSE Champions League/Cup/Trophy + Ronda de Qualificação) — ver
    // 07g-europa.js. nuvemGerada/coefPais/coefClube são inicializados lá mesmo (a nuvem de clubes
    // fictícios dos 5 países ainda não jogáveis tem de existir em state.teams antes de qualquer
    // carreira arrancar, para as finanças/identidade tática serem inicializadas por igual).
    europa: null, pendingEuropaSlot: null,
    placardChampion: null, okLigaChampion: null, serieA1Champion: null,
    okLigaRunnerUp: null, serieA1RunnerUp: null,
    promotionEvent: null, seasonTransitionApplied: false,
    transferMarket: [], transferHistory: [], marketLastRefreshSeason: null, internalTransferHistory: [], marketDecisionHistory: [], lastSeasonSummary: null,
    // Separador "Transferências" da Ficha do Clube (2026-10-04, pedido do utilizador: "a folha dos
    // clubes deve ter um separador Transferências onde se pode consultar entradas e saidas por
    // cada ano") — ledger único de movimentos reais de plantel (transferências pagas, assinaturas
    // livres, empréstimos de entrada/regresso, dispensas, fins de contrato), por clube e por época,
    // alimentado em registerPlayerEntry/releasePlayerToFreeAgency/returnSeasonLoans/processDefesoMarket
    // (04-financas.js) — ver recordClubMovement. Nunca reconstruído a partir de transferHistory/
    // loanHistory (feeds globais mais antigos, sem clubeId/época, mantidos tal como estavam para o
    // que já os usa).
    clubMovements: [],
    // Fase 12/13: contratos, pré-contratos, jogadores livres e negociações.
    freeAgents: [], defesoProcessedSeason: null, uiNegotiationOpenId: null, contractNews: [], contractNegotiations: {}, transferNegotiations: {}, loanNegotiations: {}, aiOffers: [], loanHistory: [], lastAiOfferDate: null,
    // Fase 16: mercado IA-contra-IA (defeso).
    aiToAiMarketProcessedSeason: null,
    // Fase 1 (Identidade + Familiaridade tática): último dia em que o treino tático semanal
    // (state.treinoTaticoEscolhido por clube) foi processado.
    lastTacticalTrainingDate: null,
    // Fase 2 (Relatórios do treinador adjunto): último mês em que o relatório mensal foi gerado.
    lastMonthlyTacticalReport: null,
    // Reformas + Novas Gerações: histórico de jogadores reformados e guardas de idempotência
    // por transição de época.
    retiredPlayers: [], inactivePlayers: [], youthCandidates: [], youthDecisionHistory: [], retirementsProcessedSeason: null, newGenerationProcessedSeason: null,
    // Fase 15: fluxo de defeso próprio e avaliação da direção.
    inDefeso: false, pendingSeasonSummary: null, lastDefesoStats: null,
    isPreSeasonDefeso: false, pendingSeasonStartDate: null,
    // Falência/Game Over: campos globais introduzidos na Fase 1; só serão acionados na Fase 3.
    gameOver: false, gameOverReason: null, gameOverSnapshot: null, gameOverAt: null,
    // Calibração financeira (proposta P5): fundo de solidariedade acumulado na época corrente,
    // distribuído no fecho de época pelos clubes em dificuldade — ver distributeSolidarityFund.
    fundoSolidariedadeEpoca: 0,
    // Mercado de treinadores (2026-09-23, ver 08c-staff-treinadores.js): pool de treinadores
    // despedidos ou que saíram voluntariamente de um clube de IA, ainda sem clube — candidatos a
    // preencher a próxima vaga (de outro clube de IA, ou do próprio utilizador, via
    // managerVacantEligibleClubs/applyForManagerJob). Nunca inclui o gestor humano.
    treinadoresDisponiveis: [],
  };

  function currentCompetition(){ return state.competitions[state.userCompetitionId] || null; }
  Object.defineProperty(state, "fixtures", {
    get(){ const c = currentCompetition(); return c ? c.fixtures : []; },
    set(v){ const c = currentCompetition(); if(c) c.fixtures = v; },
    enumerable: true, configurable: true,
  });
  Object.defineProperty(state, "currentRound", {
    get(){ const c = currentCompetition(); return c ? c.currentRound : 0; },
    set(v){ const c = currentCompetition(); if(c) c.currentRound = v; },
    enumerable: true, configurable: true,
  });
  Object.defineProperty(state, "playoff", {
    get(){ const c = currentCompetition(); return c ? c.playoff : null; },
    set(v){ const c = currentCompetition(); if(c) c.playoff = v; },
    enumerable: true, configurable: true,
  });

  // Real 2026/27 Campeonato Placard rosters, compiled from hoqueipatins.pt official
  // transfers tracker (jersey numbers, positions and moves are real; age/nivel/potencial/
  // temperamento are estimates the manager can freely edit in each player's card).
  const REAL_ROSTERS = window.HM2027_DATABASE.rosters;;

  CLUB_DEFS.forEach(def => {
    const rosterData = REAL_ROSTERS[def.id] || [];
    const usedIds = new Set(), usedNums = new Set();
    state.teams[def.id] = {
      id: def.id, name: def.name, color: def.primaryColor||def.color, tier: def.tier,
      divisaoAtual: def.divisaoAtual || "placard", zona: def.zona || null,
      // Correcção (auditoria externa, 2026-09-17): o país de um clube era só derivado da divisão
      // em que compete (teamCountry, 01-nucleo.js: ok-liga→es, serie-a1→it, resto→pt) — frágil a
      // qualquer competição nova (o mesmo tipo de problema já apanhado hoje no DIVISION_TIER).
      // def.pais já existe na base de dados e já era usado para o país de origem dos jogadores
      // (mais abaixo) — passa agora a ficar também guardado directamente no próprio clube, como
      // atributo institucional estável e independente da divisão onde compete nesta época.
      pais: def.pais || "pt",
      equipaPrincipalId: ({"fc-porto-b":"porto","ad-valongo-b":"valongo","oc-barcelos-b":"barcelos","ud-oliveirense-b":"oliveirense","sporting-cp-b":"sporting","sl-benfica-b":"benfica","riba-dave-hc-b":"ribadave","hc-braga-b":"braga","j-pacense-b":"pacense","ad-sanjoanense-b":"sanjoanense","ch-carvalhos-b":"ch-carvalhos","aa-espinho-b":"ass-academica-espinho","ha-cambra-b":"ha-cambra","a-academica-c-b":"ass-academica-coimbra","hc-turquel-b":"hc-turquel","hc-mealhada-b":"hc-mealhada","s-alenquer-b-b":"sp-alenquer-e-benfica","ae-fisica-d-b":"ae-fisica-d","cd-paco-de-arcos-b":"cd-paco-de-arcos"})[def.id] || null,
      equipaBId: ({"porto":"fc-porto-b","valongo":"ad-valongo-b","barcelos":"oc-barcelos-b","oliveirense":"ud-oliveirense-b","sporting":"sporting-cp-b","benfica":"sl-benfica-b","ribadave":"riba-dave-hc-b","braga":"hc-braga-b","pacense":"j-pacense-b","sanjoanense":"ad-sanjoanense-b","ch-carvalhos":"ch-carvalhos-b","ass-academica-espinho":"aa-espinho-b","ha-cambra":"ha-cambra-b","ass-academica-coimbra":"a-academica-c-b","hc-turquel":"hc-turquel-b","hc-mealhada":"hc-mealhada-b","sp-alenquer-e-benfica":"s-alenquer-b-b","ae-fisica-d":"ae-fisica-d-b","cd-paco-de-arcos":"cd-paco-de-arcos-b"})[def.id] || null,
      // Sistema numérico de reputação (01-nucleo.js): normalizeClubReputation aceita o valor já
      // numérico da base de dados atual, uma categoria antiga (compatibilidade), ou nenhum
      // valor (usa o valor por omissão da divisão/clube — ver reputationDefaultForClub).
      reputacao: normalizeClubReputation(def.reputacao, def), reputacaoPontos: normalizeClubReputation(def.reputacao, def),
      reputacaoClube: normalizeClubReputation(def.reputacao, def), desempenhoRecente:50, capacidadeFinanceira: normalizeClubReputation(def.reputacao, def), massaAdepta: normalizeClubReputation(def.reputacao, def),
      condicoesTreino: def.condicoesTreino,
      // Barómetro contínuo de confiança da direção (pedido do utilizador, 2026-09-14): valor
      // neutro por omissão — sobe/desce jogo a jogo em updateDirectionConfidenceAfterMatch
      // (04-financas.js), só para o(s) clube(s) controlados pelo utilizador.
      confiancaDirecao: 60,
      pavilhao: def.pavilhao || null, cidadePavilhao: def.cidadePavilhao || null,
      // Ajuste financeiro manual, pontual, para um clube específico (pedido do utilizador,
      // 2026-09-13: "Tira 50000 da caixa e baixa o patrocínio para aprox 120000" no CH Lloret) —
      // opcional, null por omissão. Quando definido, financeConfig (04-financas.js) usa este valor
      // fixo em vez da fórmula genérica por reputação, só para o saldo inicial e/ou o patrocínio
      // anual — todo o resto do clube (capacidade, quotas, limite salarial, objetivo desportivo)
      // continua a evoluir normalmente com a reputação, sem ficar "congelado" como aconteceria ao
      // usar CLUB_FINANCE_PROFILES para isto.
      saldoInicialManual: def.saldoInicialManual!=null ? def.saldoInicialManual : null,
      patrocinioAnualManual: def.patrocinioAnualManual!=null ? def.patrocinioAnualManual : null,
      // Plantéis reais da base de dados são usados TAL COMO ESTÃO (pedido do utilizador,
      // 2026-10-05: "não quero alterações aos plantéis reais") — nunca se acrescentam jogadores
      // gerados a um clube com dados reais, mesmo que incompletos; as faltas são resolvidas, como
      // sempre, pelo mercado/livres e pelo GR provisório em dia de jogo. Só os clubes sem
      // qualquer dado real recebem um plantel gerado (generatePlaceholderRoster, abaixo).
      players: rosterData.length
        ? rosterData.map((raw, idx) => normalizeImportedPlayer(raw, idx, def.id, usedIds, usedNums, def.divisaoAtual, def.pais||"pt"))
        // Correção (2026-09-14, pedido do utilizador: "os jogadores da liga italiana estao
        // absurdamente bons"): esta chamada nunca passava a reputação do clube (só tier/divisão/
        // país), por isso o novo serieA1PlaceholderBase (que depende da reputação) nunca era
        // efetivamente usado para a Serie A1 — confirmado por medição empírica (média de OVR
        // inalterada em 15.14 antes e depois de o adicionar a generatePlaceholderRoster). Passa a
        // sempre passar a reputação já normalizada do clube; só afeta a Serie A1 (e, tal como já
        // acontecia, a nuvem europeia) — as restantes divisões continuam a usar tierBaseLevel.
        : generatePlaceholderRoster(def.id, def.tier, def.divisaoAtual, def.pais||"pt", normalizeClubReputation(def.reputacao, def)),
      sistema: "3-1", mentalidade: "equilibrado", pressao: "media", provisional: rosterData.length === 0,
      stats: { J:0, V:0, E:0, D:0, GM:0, GS:0, Pts:0 },
      // Academia e Juvenis (substitui por completo o antigo generateNewGeneration/
      // youthCandidates/qualidadeFormacao, decisão do utilizador de 2026-09-22): clubes de 3ª
      // divisão e clubes "nuvem" europeia nunca têm academia (ver academyEligible,
      // 08b-academia-juvenis.js) — ficam com null aqui; bootstrapAcademyIfEmpty cria a forma
      // completa (com os 4 escalões já preenchidos) para os clubes elegíveis, seja ao arrancar
      // uma carreira nova, ao carregar uma gravação antiga, ou no momento em que um clube sobe
      // da 3ª para a 2ª divisão (07-playoff.js, applyPromotionAndRelegation).
      academy: null,
      // Staff — Treinadores (pedido do utilizador, 2026-09-22: "Quero criar staff a começar
      // pelos treinadores"): todos os clubes elegíveis têm um treinador próprio, com stats
      // 0-20 (mesma escala dos jogadores), nacionalidade, histórico de clubes e um registo de
      // resultados do mandato em curso. null aqui, tal como "academy" — bootstrapTreinadorIfEmpty
      // (08c-staff-treinadores.js) cria o treinador para os clubes elegíveis (mesma regra de
      // elegibilidade da Academia: sem equipas B, sem 3ª divisão, sem "nuvem" europeia).
      treinador: null,
    };
  });

  // Empréstimos iniciais da base de dados (2026-10-15, pedido do utilizador: Rodrigo Preciso e
  // Diogo Duarte no Tomar por empréstimo do Benfica B, Miguel Franco no Viana por empréstimo do
  // Sporting B — até ao fim da época, sem chamada de volta e sem opção de compra). Um jogador do
  // plantel da base de dados com "emprestimoDe": "<id do clube dono>" entra já como emprestado:
  // fica no plantel do clube onde está (destino) com o mesmo registo que completeLoan cria
  // (player.emprestimo), e regressa ao dono no fim da época (returnSeason, returnSeasonLoans).
  CLUB_DEFS.forEach(def => {
    (REAL_ROSTERS[def.id] || []).forEach(raw => {
      if(!raw || !raw.emprestimoDe || !state.teams[raw.emprestimoDe]) return;
      const dest = state.teams[def.id];
      const pl = dest.players.find(x => x.id === (raw.id ? String(raw.id).slice(0,80) : x.id) && x.name === String(raw.name||"").trim().slice(0,40));
      if(!pl) return;
      pl.emprestimo = {
        ownerId: raw.emprestimoDe, destinationId: def.id, salaryShare: 50, papel: "Rotacao",
        startSeason: state.season, returnSeason: state.season + 1,
        clausulas: { opcaoCompra: null, usoMinimo: null, chamada: false },
        inicio: null, rondaInicio: 0, jogosInicio: 0, golosInicio: 0, titularInicio: 0, notasInicio: 0,
        ovrInicio: overall(pl), chamadaUsada: false, inicial: true,
      };
    });
  });

  // Competição única jogável pelo utilizador por agora: o Campeonato Placard (Fase 1/2 da 2ª
  // Divisão). Filtra-se por divisaoAtual, para as equipas da 2ª Divisão não entrarem aqui.
  const placardClubIds = CLUB_DEFS.filter(d=>d.divisaoAtual==="placard").map(d=>d.id);
  state.competitions["placard-2026-27"] = {
    id: "placard-2026-27", divisionId: "placard", zona: null, epoca: state.season,
    teamIds: placardClubIds,
    fixtures: [], currentRound: 0, playoff: null,
    status: "regular", reputacaoCompeticao:90,
  };
  state.userCompetitionId = "placard-2026-27";

  // Liga espanhola (OK Liga, 1ª divisão, 14 clubes) — v1: só liga regular + playoff, sem 2ª
  // divisão (OK Liga Plata) nem Copa del Rey. Corre exatamente como o Placard, em paralelo,
  // através da mesma agenda diária genérica — o utilizador escolhe entre gerir um clube
  // português ou espanhol logo no início da carreira (novo passo "País"), e a competição do país
  // que não escolheu continua a decorrer inteiramente por IA, tal como já acontece com a 2ª e 3ª
  // Divisões portuguesas quando o utilizador está no Placard.
  const okLigaClubIds = CLUB_DEFS.filter(d=>d.divisaoAtual==="ok-liga").map(d=>d.id);
  state.competitions["ok-liga-2026-27"] = {
    id: "ok-liga-2026-27", divisionId: "ok-liga", zona: null, epoca: state.season,
    teamIds: okLigaClubIds,
    fixtures: [], currentRound: 0, playoff: null,
    // Reputação da liga (2026-09-06, indicado pelo utilizador): a OK Liga tem, neste momento,
    // menos 15% de reputação do que o Campeonato Placard (90 -> 77) — usada em
    // competitionPrestigeForTeam/clubAppeal (04-financas.js), com impacto nas negociações e nas
    // transferências entre países.
    status: "regular", reputacaoCompeticao: 77,
  };

  // Liga italiana (Serie A1, 1ª divisão, 14 clubes) — v1: só liga regular + playoff (com o Turno
  // Preliminar real entre 7º-10º, ver PLAYOFF_DIVISION_CONFIG em 07-playoff.js), sem Serie A2
  // nem o playout de descida (posições 11-14, regulamento real da FISR) — à semelhança da
  // decisão já tomada para a OK Liga, não há uma 2ª divisão italiana modelada para onde descer
  // ninguém, por isso os últimos classificados ficam só assinalados na tabela, sem consequência
  // prática (mesmo princípio já usado na 3ª Divisão portuguesa, o escalão mais baixo modelado).
  // Terceiro país jogável, em paralelo com Portugal e Espanha, através da mesma agenda diária
  // genérica (ver processPhaseFiveFinalsForCurrentDate, 07-playoff.js).
  const serieA1ClubIds = CLUB_DEFS.filter(d=>d.divisaoAtual==="serie-a1").map(d=>d.id);
  state.competitions["serie-a1-2026-27"] = {
    id: "serie-a1-2026-27", divisionId: "serie-a1", zona: null, epoca: state.season,
    teamIds: serieA1ClubIds,
    fixtures: [], currentRound: 0, playoff: null,
    // Reputação da liga (2026-09-06, indicado pelo utilizador): a Serie A1 tem, neste momento,
    // menos 15% de reputação do que a OK Liga (77 -> 65,45, arredondado a 65) — usada em
    // competitionPrestigeForTeam/clubAppeal (04-financas.js), com impacto nas negociações e nas
    // transferências entre países.
    status: "regular", reputacaoCompeticao: 65,
  };

  // Fase 2 da 2ª Divisão: Zona Norte e Zona Sul já existem como competições reais, simuladas
  // integralmente por IA (o utilizador ainda só pode escolher clubes do Placard — isso é só na
  // Fase 4). Corre em paralelo com o Placard através da mesma agenda de avanço diário.
  ["norte","sul"].forEach(zona => {
    const teamIds = CLUB_DEFS.filter(d=>d.divisaoAtual==="2div" && d.zona===zona).map(d=>d.id);
    state.competitions["2div-"+zona+"-2026-27"] = {
      id: "2div-"+zona+"-2026-27", divisionId: "2div", zona, epoca: state.season,
      teamIds,
      fixtures: [], currentRound: 0, playoff: null,
      status: "regular", reputacaoCompeticao:50,
    };
  });

  // 3ª Divisão: 4 zonas (Norte A/B, Sul A/B) — simulada integralmente por IA por agora, não
  // escolhível pelo utilizador ("só simulação", tal como combinado). A Zona Sul A tem 13
  // equipas em vez de 14 (número real da competição oficial) — generateValidatedFixtures já
  // suporta números ímpares de equipas com um "bye" rotativo por jornada, sem precisar de
  // nenhuma alteração.
  ["norte-a","norte-b","sul-a","sul-b"].forEach(zona => {
    const teamIds = CLUB_DEFS.filter(d=>d.divisaoAtual==="3div" && d.zona===zona).map(d=>d.id);
    state.competitions["3div-"+zona+"-2026-27"] = {
      id: "3div-"+zona+"-2026-27", divisionId: "3div", zona, epoca: state.season,
      teamIds,
      fixtures: [], currentRound: 0, playoff: null,
      status: "regular", reputacaoCompeticao:30,
    };
  });

  // Validação leve dos plantéis no arranque — só regista avisos na consola, nunca bloqueia o
  // jogo (útil para detetar planteis incompletos ao adicionar/editar bases de dados reais).
  (function validateRostersAtStartup(){
    Object.values(state.teams).forEach(t => {
      const grs = t.players.filter(p=>p.pos==="GR").length;
      const js = t.players.length - grs;
      if(grs < 1) console.warn(`[HM2027] ${t.name}: sem guarda-redes no plantel.`);
      if(js < 4) console.warn(`[HM2027] ${t.name}: só tem ${js} jogadores de campo (mínimo recomendado: 4).`);
      const ids = t.players.map(p=>p.id);
      const dupIds = ids.filter((id,i)=>ids.indexOf(id)!==i);
      if(dupIds.length) console.warn(`[HM2027] ${t.name}: IDs de jogador duplicados:`, [...new Set(dupIds)]);
    });
  })();

  function myTeam(){ return state.teams[state.userTeamId]; }

  // =================================================================
