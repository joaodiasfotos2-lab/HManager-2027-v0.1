// Clubes satélite (2026-10-12, pedido do utilizador: ideia 4 da décima lista).
// Decisões de desenho confirmadas por ele:
//  - o acordo inclui: EMPRÉSTIMO DE JOVENS (com minutos garantidos), DIREITO DE PREFERÊNCIA na
//    compra de jogadores do satélite e APOIO FINANCEIRO anual;
//  - cada clube tem no máximo 1 satélite, sempre numa divisão imediatamente abaixo e do mesmo país
//    (Placard → 2.ª Divisão, 2.ª Divisão → 3.ª Divisão);
//  - a IA também tem satélites (empresta jovens e exerce a preferência).
//
// Reaproveita o sistema de empréstimos (08i-emprestimos.js): um empréstimo ao satélite leva as
// cláusulas "utilização mínima de 60% dos jogos (se falhar: devolução)" e "chamada de volta", é pago
// por inteiro pelo clube principal e dura a época (regresso automático no fim). A preferência usa a
// transferência definitiva normal (applyAcceptedOffer) com o preço combinado, só na janela de
// inscrições, no máximo uma por época e por acordo.
//
// Todos os valores numéricos são ESTIMATIVAS (o RGHP não regula acordos entre clubes): níveis de
// apoio por escalão do satélite, desconto de 10% a 25% na preferência (sobe com o apoio), limite
// de 4 emprestados em simultâneo, probabilidade de aceitação do satélite, comportamento da IA.
// A IA não movimenta dinheiro de apoio (só o clube do utilizador paga), para não mexer na
// calibração financeira.
//
// Dados globais em state.satelites (guardado com o jogo):
//   acordos  { "<principalId>": { principalId, sateliteId, desde, apoio 0–3, preferencia, epocaIA, compraEpoca } }
//   pedidos  [ { id, principalId, sateliteId, apoio, preferencia, data, resolve } ]  propostas do utilizador
//   iniciado  true depois de criados os acordos iniciais da IA

const SAT_APOIO_ANUAL = {            // € por ano, consoante o escalão do satélite (2 = 2.ª divisão, 1 = 3.ª divisão)
  2: [0, 6000, 15000, 30000],
  1: [0, 3000, 8000, 16000],
};
const SAT_APOIO_ROTULO = ["Sem apoio", "Apoio ligeiro", "Apoio médio", "Apoio forte"];
const SAT_MAX_EMPRESTADOS = 4;
const SAT_IDADE_EMPRESTIMO = 23;
const SAT_IDADE_PROSPECTO = 23;
const SAT_USO_MINIMO_PCT = 60;
const SAT_PROB_ACORDO_IA = { 3: 0.6, 2: 0.35 };    // probabilidade de uma equipa de IA ter satélite, por escalão
const SAT_PROB_PREFERENCIA_IA = 0.3;

function satEnsure(){
  if(!state.satelites || typeof state.satelites !== "object") state.satelites = { v: 1, acordos: {}, pedidos: [], iniciado: false, seq: 0 };
  const s = state.satelites;
  if(!s.acordos) s.acordos = {};
  if(!Array.isArray(s.pedidos)) s.pedidos = [];
  if(s.seq == null) s.seq = 0;
  if(!s.iniciado && state.teams && Object.keys(state.teams).length){ s.iniciado = true; satCriarAcordosIA(s); }
  return s;
}
function satPais(team){ return typeof viagemPais === "function" ? (viagemPais(team) || "pt") : "pt"; }
function satRank(team){ return teamDivisionRank(team); }
function satSateliteDe(principalId){
  const s = satEnsure(); const a = s.acordos[principalId];
  return a ? state.teams[a.sateliteId] || null : null;
}
function satAcordoDoSatelite(sateliteId){
  const s = satEnsure();
  return Object.values(s.acordos).find(a => a.sateliteId === sateliteId) || null;
}
function satApoioAnual(sat, nivel){
  const tabela = SAT_APOIO_ANUAL[satRank(sat)] || SAT_APOIO_ANUAL[1];
  return tabela[clamp(nivel, 0, 3)];
}
// Clubes que podem ser satélite de `principal`: uma divisão abaixo, mesmo país, sem outro acordo.
function satElegiveis(principal){
  if(!principal || principal.equipaPrincipalId) return [];
  const rank = satRank(principal);
  if(rank < 2) return [];
  const s = satEnsure();
  const usados = new Set(Object.values(s.acordos).map(a => a.sateliteId));
  const principais = new Set(Object.keys(s.acordos));
  return Object.values(state.teams).filter(t =>
    t.id !== principal.id && !t.equipaPrincipalId && !t.nuvemEuropeia && !t.selecaoNacional &&
    !(typeof isBTeamId === "function" && isBTeamId(t.id)) &&
    satRank(t) === rank - 1 && satPais(t) === satPais(principal) &&
    !usados.has(t.id) && !principais.has(t.id) && !isUserControlledTeam(t)
  );
}
function satCriarAcordosIA(s){
  const jaPrincipais = new Set();
  Object.values(state.teams).forEach(t => {
    if(t.equipaPrincipalId || t.nuvemEuropeia || t.selecaoNacional || isUserControlledTeam(t)) return;
    if(typeof isBTeamId === "function" && isBTeamId(t.id)) return;
    const p = SAT_PROB_ACORDO_IA[satRank(t)]; if(!p) return;
    const rng = makeSeededRng(`satelite|${t.id}`);
    if(rng() > p) return;
    const cands = satElegiveis(t);
    if(!cands.length) return;
    // prefere um satélite da mesma zona geográfica
    const zona = typeof viagemZona === "function" ? viagemZona(t) : null;
    const mesmaZona = zona ? cands.filter(c => viagemZona(c) === zona) : [];
    const lista = mesmaZona.length ? mesmaZona : cands;
    const sat = lista[Math.floor(rng() * lista.length)];
    s.acordos[t.id] = { principalId: t.id, sateliteId: sat.id, desde: state.season, apoio: Math.floor(rng() * 3), preferencia: rng() < 0.7, epocaIA: null, compraEpoca: null };
    jaPrincipais.add(t.id);
  });
}

// ---------------------------------------------------------------- proposta do utilizador
function satPropor(sateliteId, apoio, preferencia){
  const team = myTeam(); if(!team) return { ok: false, reason: "Sem clube." };
  const s = satEnsure();
  if(s.acordos[team.id]) return { ok: false, reason: "O clube já tem um satélite." };
  if(s.pedidos.some(p => p.principalId === team.id)) return { ok: false, reason: "Já há uma proposta à espera de resposta." };
  if(satRank(team) < 2) return { ok: false, reason: "Só clubes da 2.ª divisão ou superior podem ter um satélite (não há divisão abaixo)." };
  const sat = satElegiveis(team).find(t => t.id === sateliteId);
  if(!sat) return { ok: false, reason: "Esse clube não pode ser satélite do teu (divisão, país ou já tem acordo)." };
  const rec = s.recusas && s.recusas[`${team.id}|${sat.id}`];
  if(rec && rec > isoDate(state.currentDate)) return { ok: false, reason: `${sat.name} recusou há pouco tempo: só volta a ouvir propostas a partir de ${fmtDateShort(new Date(rec))}.` };
  apoio = clamp(Math.round(apoio) || 0, 0, 3);
  const dias = 5 + Math.floor(Math.random() * 6);
  s.seq += 1;
  s.pedidos.push({ id: `sat${s.seq}`, principalId: team.id, sateliteId: sat.id, apoio, preferencia: !!preferencia, data: isoDate(state.currentDate), resolve: isoDate(addDays(new Date(state.currentDate), dias)) });
  return { ok: true, dias };
}
function satScoreAceitacao(principal, sat, apoio, preferencia){
  const rp = principal.reputacaoClube != null ? principal.reputacaoClube : (principal.reputacao != null ? principal.reputacao : 50);
  const rs = sat.reputacaoClube != null ? sat.reputacaoClube : (sat.reputacao != null ? sat.reputacao : 40);
  return 35 + clamp((rp - rs) * 0.4, 0, 20) + apoio * 13 - (preferencia ? 12 : 0);
}
function satResolverPedidos(){
  const s = satEnsure(); if(!s.pedidos.length) return;
  const hoje = isoDate(state.currentDate), restantes = [];
  s.pedidos.forEach(p => {
    if(p.resolve > hoje){ restantes.push(p); return; }
    const principal = state.teams[p.principalId], sat = state.teams[p.sateliteId];
    if(!principal || !sat) return;
    if(!satElegiveis(principal).some(t => t.id === sat.id) || s.acordos[principal.id]){
      pushNews(state.currentDate, `A proposta de acordo de satélite com ${teamLinkHtml(sat.id)} caducou: o clube já não está disponível.`, "mercado", "Proposta de satélite caducada");
      return;
    }
    const score = satScoreAceitacao(principal, sat, p.apoio, p.preferencia) + (Math.random() * 16 - 8);
    if(score >= 55){
      s.acordos[principal.id] = { principalId: principal.id, sateliteId: sat.id, desde: state.season, apoio: p.apoio, preferencia: p.preferencia, epocaIA: null, compraEpoca: null };
      pushNews(state.currentDate, `${teamLinkHtml(sat.id)} aceitou ser clube satélite de ${teamLinkHtml(principal.id)}. ${p.apoio ? "Apoio anual de " + fmtMoney(satApoioAnual(sat, p.apoio)) + "." : "Sem apoio financeiro."} ${p.preferencia ? "Direito de preferência incluído." : "Sem direito de preferência."}`, "mercado", "Acordo de clube satélite", { autoAdvanceStop: true });
    } else {
      const motivo = p.preferencia && p.apoio < 2 ? "o clube não quis ceder o direito de preferência sem mais apoio financeiro" : p.apoio === 0 ? "o clube pediu apoio financeiro" : "a proposta não foi suficientemente atrativa";
      if(!s.recusas) s.recusas = {};
      s.recusas[`${principal.id}|${sat.id}`] = isoDate(addDays(new Date(state.currentDate), 60));
      pushNews(state.currentDate, `${teamLinkHtml(sat.id)} recusou o acordo de satélite proposto por ${teamLinkHtml(principal.id)}: ${motivo}.`, "mercado", "Acordo de satélite recusado", { autoAdvanceStop: true });
    }
  });
  s.pedidos = restantes;
}
function satTerminar(){
  const team = myTeam(); if(!team) return { ok: false, reason: "Sem clube." };
  const s = satEnsure(); const a = s.acordos[team.id];
  if(!a) return { ok: false, reason: "Não tens nenhum acordo de satélite." };
  const sat = state.teams[a.sateliteId];
  delete s.acordos[team.id];
  pushNews(state.currentDate, `${teamLinkHtml(team.id)} pôs fim ao acordo de satélite com ${sat ? teamLinkHtml(sat.id) : "o clube"}. Os jogadores emprestados mantêm-se até ao fim da época.`, "mercado", "Fim do acordo de satélite");
  return { ok: true };
}
function satMudarApoio(nivel){
  const team = myTeam(); if(!team) return { ok: false, reason: "Sem clube." };
  const a = satEnsure().acordos[team.id];
  if(!a) return { ok: false, reason: "Não tens nenhum acordo de satélite." };
  a.apoio = clamp(Math.round(nivel) || 0, 0, 3);
  return { ok: true };
}

// ---------------------------------------------------------------- empréstimos ao satélite
function satEmprestadosAoSatelite(principalId){
  const a = satEnsure().acordos[principalId]; if(!a) return [];
  const sat = state.teams[a.sateliteId]; if(!sat) return [];
  return sat.players.filter(p => p.emprestimo && p.emprestimo.ownerId === principalId);
}
function satPodeEmprestar(player, principal, sat){
  if(!player || !principal || !sat) return { ok: false, reason: "Dados inválidos." };
  if(player.emprestimo) return { ok: false, reason: "O jogador já está emprestado." };
  if(player.pendingTransferHold) return { ok: false, reason: "O jogador tem uma transferência acordada." };
  if(player.age > SAT_IDADE_EMPRESTIMO) return { ok: false, reason: `Só jogadores até aos ${SAT_IDADE_EMPRESTIMO} anos podem ir para o satélite.` };
  if((player.reputacaoJogador || 0) >= 55) return { ok: false, reason: "Jogador com reputação demasiado alta para ser emprestado a um satélite." };
  if(playerTransferLimitReached(player)) return { ok: false, reason: "Este jogador já mudou de clube esta época." };
  if(satEmprestadosAoSatelite(principal.id).length >= SAT_MAX_EMPRESTADOS) return { ok: false, reason: `O satélite já tem ${SAT_MAX_EMPRESTADOS} jogadores teus emprestados.` };
  return { ok: true };
}
function satEmprestar(playerId){
  const team = myTeam(); if(!team) return { ok: false, reason: "Sem clube." };
  const a = satEnsure().acordos[team.id]; if(!a) return { ok: false, reason: "Não tens nenhum acordo de satélite." };
  const sat = state.teams[a.sateliteId]; const player = team.players.find(p => p.id === playerId);
  const chk = satPodeEmprestar(player, team, sat); if(!chk.ok) return chk;
  return satFazerEmprestimo(player, team, sat);
}
function satFazerEmprestimo(player, principal, sat){
  const r = completeLoan(player, principal, sat, 0, "Titular", { opcaoCompra: null, usoMinimo: { pct: SAT_USO_MINIMO_PCT, remedio: "retorno" }, chamada: true }, { silencioso: !isUserControlledTeam(principal) });
  if(r && r.ok !== false && player.emprestimo){ player.emprestimo.satelite = true; return { ok: true }; }
  return r || { ok: false, reason: "Não foi possível emprestar." };
}
function satJovensParaEmprestar(team){
  const a = satEnsure().acordos[team.id]; if(!a) return [];
  const sat = state.teams[a.sateliteId];
  return team.players.filter(p => satPodeEmprestar(p, team, sat).ok && !p.__provisional).sort((x, y) => overall(y) - overall(x)).slice(0, 10);
}

// ---------------------------------------------------------------- direito de preferência
function satDesconto(a){ return 0.90 - 0.05 * clamp(a.apoio, 0, 3); }
function satPrecoPreferencia(player, a){
  const sat = state.teams[a.sateliteId];
  return Math.max(500, Math.round(playerMarketValue(player, sat) * satDesconto(a) / 500) * 500);
}
function satProspectos(principalId){
  const a = satEnsure().acordos[principalId]; if(!a) return [];
  const sat = state.teams[a.sateliteId]; if(!sat) return [];
  return sat.players.filter(p => !p.emprestimo && !p.__provisional && p.age <= SAT_IDADE_PROSPECTO).sort((x, y) => overall(y) - overall(x)).slice(0, 6);
}
function satPodeContratar(player, principal, a, preco){
  const sat = state.teams[a.sateliteId];
  if(!a.preferencia) return { ok: false, reason: "O acordo não inclui direito de preferência." };
  if(a.compraEpoca === state.season) return { ok: false, reason: "O satélite só cede um jogador por época ao abrigo da preferência." };
  if(!registrationWindowOpenFor(state.currentDate || new Date())) return { ok: false, reason: "A janela de inscrições está fechada." };
  if(!player || !sat) return { ok: false, reason: "Jogador inválido." };
  if(player.emprestimo || player.pendingTransferHold) return { ok: false, reason: "O jogador não está disponível." };
  if(playerTransferLimitReached(player)) return { ok: false, reason: "Este jogador já mudou de clube esta época." };
  const chk = canReleasePlayerFromTeam(sat, player); if(!chk.ok) return { ok: false, reason: chk.reason };
  initClubFinance(principal);
  if((principal.financeiro.saldo || 0) < preco) return { ok: false, reason: `Saldo insuficiente (preço ${fmtMoney(preco)}).` };
  if((principal.financeiro.orcamentoTransferencias || 0) < preco) return { ok: false, reason: `Orçamento de transferências insuficiente (preço ${fmtMoney(preco)}).` };
  return { ok: true };
}
function satContratar(playerId){
  const team = myTeam(); if(!team) return { ok: false, reason: "Sem clube." };
  const a = satEnsure().acordos[team.id]; if(!a) return { ok: false, reason: "Não tens nenhum acordo de satélite." };
  const sat = state.teams[a.sateliteId]; const player = sat && sat.players.find(p => p.id === playerId);
  const preco = player ? satPrecoPreferencia(player, a) : 0;
  const chk = satPodeContratar(player, team, a, preco); if(!chk.ok) return chk;
  satExecutarCompra(player, team, sat, a, preco);
  return { ok: true, preco };
}
function satExecutarCompra(player, principal, sat, a, preco){
  const sal = Math.round(expectedSalary(player, principal) * 0.9 / 10) * 10;
  applyAcceptedOffer("transferencia", player, sat, principal, { salarioMensal: sal, anos: 3, papel: player.age <= 19 ? "Desenvolvimento" : "Rotacao" }, { skipWindowCheck: true, feeOverride: preco });
  a.compraEpoca = state.season;
}

// ---------------------------------------------------------------- IA, finanças e manutenção
function satIaEpoca(a){
  const principal = state.teams[a.principalId], sat = state.teams[a.sateliteId];
  if(!principal || !sat || isUserControlledTeam(principal)) return;
  a.epocaIA = state.season;
  // empresta até 2 jovens que não contam para o onze
  const cands = principal.players.filter(p => !p.titular && !p.emprestimo && !p.__provisional && p.age <= 22 && satPodeEmprestar(p, principal, sat).ok && canReleasePlayerFromTeam(principal, p).ok)
    .sort((x, y) => overall(x) - overall(y)).slice(0, 2);
  cands.forEach(p => { if(satEmprestadosAoSatelite(principal.id).length < SAT_MAX_EMPRESTADOS) satFazerEmprestimo(p, principal, sat); });
  // por vezes exerce a preferência no melhor prospeto do satélite
  if(a.preferencia && Math.random() < SAT_PROB_PREFERENCIA_IA){
    const mediana = principal.players.length ? principal.players.map(p => overall(p)).sort((x, y) => x - y)[Math.floor(principal.players.length / 2)] : 10;
    const alvo = sat.players.filter(p => !p.emprestimo && p.age <= 21).sort((x, y) => overall(y) - overall(x))[0];
    if(alvo && overall(alvo) >= mediana - 1){
      const preco = satPrecoPreferencia(alvo, a);
      if(satPodeContratar(alvo, principal, a, preco).ok) satExecutarCompra(alvo, principal, sat, a, preco);
    }
  }
}
function satValidar(){
  const s = satEnsure();
  Object.keys(s.acordos).forEach(pid => {
    const a = s.acordos[pid], principal = state.teams[pid], sat = state.teams[a.sateliteId];
    if(principal && sat && satRank(principal) - satRank(sat) === 1 && satPais(principal) === satPais(sat)) return;
    delete s.acordos[pid];
    if(principal && isUserControlledTeam(principal)) pushNews(state.currentDate, `O acordo de satélite entre ${teamLinkHtml(principal.id)} e ${sat ? teamLinkHtml(sat.id) : "o clube"} caducou: os clubes já não estão em divisões consecutivas.`, "mercado", "Acordo de satélite caducado", { autoAdvanceStop: true });
  });
}
function satMensal(date){
  const s = satEnsure();
  satValidar();
  Object.values(s.acordos).forEach(a => {
    const principal = state.teams[a.principalId], sat = state.teams[a.sateliteId]; if(!principal || !sat) return;
    // apoio financeiro: só o utilizador paga (a IA não movimenta dinheiro)
    if(isUserControlledTeam(principal) && a.apoio > 0){
      const mensal = Math.round(satApoioAnual(sat, a.apoio) / 12 / 10) * 10;
      if(mensal > 0){
        addFinanceMovement(principal, "despesa", "Apoio a clube satélite", `Apoio ao satélite ${sat.name}`, mensal, date);
        initClubFinance(sat); addFinanceMovement(sat, "receita", "Apoio do clube principal", `Apoio de ${principal.name}`, mensal, date);
      }
    }
    // início de época: a IA empresta jovens e, por vezes, exerce a preferência
    if(!isUserControlledTeam(principal) && a.epocaIA !== state.season && registrationWindowOpenFor(date)) satIaEpoca(a);
  });
}

// ---------------------------------------------------------------- painel (Direção)
function satPanelHtml(team){
  if(!team || !isUserControlledTeam(team)) return "";
  const s = satEnsure(), a = s.acordos[team.id];
  const cab = `<div class="eyebrow" style="margin:16px 0 8px;">Clube satélite</div>`;
  if(satRank(team) < 2) return cab + `<p class="helptext">Só clubes da 2.ª divisão ou superior podem ter um satélite (precisa de uma divisão abaixo).</p>`;
  if(!a){
    const pend = s.pedidos.find(p => p.principalId === team.id);
    if(pend){
      const sat = state.teams[pend.sateliteId];
      return cab + `<p class="helptext">Proposta enviada a <b>${sat ? escapeHtml(sat.name) : "?"}</b> (${SAT_APOIO_ROTULO[pend.apoio].toLowerCase()}${pend.preferencia ? ", com direito de preferência" : ""}). Resposta prevista até ${fmtDateShort(new Date(pend.resolve))}.</p>`;
    }
    const cands = satElegiveis(team).sort((x, y) => (y.reputacaoClube || y.reputacao || 0) - (x.reputacaoClube || x.reputacao || 0));
    if(!cands.length) return cab + `<p class="helptext">Não há clubes disponíveis para satélite (uma divisão abaixo, no mesmo país).</p>`;
    const sats = cands.map(t => `<option value="${t.id}">${escapeHtml(t.name)}</option>`).join("");
    const rank = satRank(team) - 1;
    const apoios = SAT_APOIO_ROTULO.map((r, i) => `<option value="${i}" ${i === 1 ? "selected" : ""}>${r}${i ? " (" + fmtMoney((SAT_APOIO_ANUAL[rank] || SAT_APOIO_ANUAL[1])[i]) + "/ano)" : ""}</option>`).join("");
    return cab + `<p class="helptext" style="margin-bottom:6px;">Um clube satélite recebe os teus jovens emprestados com minutos garantidos, pode dar-te preferência na compra dos seus melhores jogadores e, em troca, precisa de apoio financeiro. Um só satélite, de uma divisão abaixo.</p>
      <div style="display:flex;gap:6px;flex-wrap:wrap;align-items:center;">
        <select id="satSel">${sats}</select><select id="satApoioSel">${apoios}</select>
        <label><input type="checkbox" id="satPrefChk"> Direito de preferência</label>
        <button class="btn btn-ghost sat-propor">Propor acordo</button></div>
      <p class="helptext" style="margin-top:6px;">O satélite responde em 5 a 10 dias. Pedir preferência sem apoio financeiro costuma ser recusado.</p>`;
  }
  const sat = state.teams[a.sateliteId];
  if(!sat) return cab + `<p class="helptext">Satélite indisponível.</p>`;
  const anual = satApoioAnual(sat, a.apoio);
  const apoios = SAT_APOIO_ROTULO.map((r, i) => `<option value="${i}" ${i === a.apoio ? "selected" : ""}>${r}${i ? " (" + fmtMoney(satApoioAnual(sat, i)) + "/ano)" : ""}</option>`).join("");
  const emp = satEmprestadosAoSatelite(team.id);
  const linhasEmp = emp.length ? emp.map(p => {
    const st = typeof empStats === "function" ? empStats(p) : null;
    return `<tr><td>${playerLinkHtml(sat.id, p)}</td><td>${p.age}</td><td>${overall(p)}</td><td>${st ? st.jogos + " jogos, " + st.golos + " golos" : "—"}</td><td><button class="btn btn-ghost sat-chamar" data-id="${p.id}">Chamar de volta</button></td></tr>`;
  }).join("") : `<tr><td colspan="5" class="helptext">Nenhum jogador emprestado ao satélite.</td></tr>`;
  const jovens = satJovensParaEmprestar(team);
  const opcoesEmp = jovens.length ? jovens.map(p => `<option value="${p.id}">${escapeHtml(p.name)} (${p.age} anos, OVR ${overall(p)})</option>`).join("") : "";
  const prosp = satProspectos(team.id);
  const linhasProsp = prosp.length ? prosp.map(p => {
    const preco = satPrecoPreferencia(p, a), chk = satPodeContratar(p, team, a, preco);
    return `<tr><td>${playerLinkHtml(sat.id, p)}</td><td>${p.age}</td><td>${overall(p)}</td><td>${fmtMoney(preco)}</td><td><button class="btn btn-ghost sat-contratar" data-id="${p.id}" ${chk.ok ? "" : "disabled"} title="${chk.ok ? "" : escapeHtml(chk.reason)}">Contratar</button></td></tr>`;
  }).join("") : `<tr><td colspan="5" class="helptext">O satélite não tem jovens de interesse.</td></tr>`;
  return cab + `<p class="helptext" style="margin-bottom:6px;">Satélite: <b>${escapeHtml(sat.name)}</b> (${a.preferencia ? "com" : "sem"} direito de preferência) · desde a época ${seasonLabel(a.desde)} · apoio ${anual ? fmtMoney(anual) + "/ano" : "nenhum"}.</p>
    <div style="display:flex;gap:6px;flex-wrap:wrap;align-items:center;margin-bottom:8px;">
      <select id="satApoioMud">${apoios}</select><button class="btn btn-ghost sat-apoio">Alterar apoio</button>
      <button class="btn btn-ghost sat-terminar">Terminar acordo</button></div>
    <div class="helptext" style="margin-bottom:4px;">Emprestados ao satélite (${emp.length}/${SAT_MAX_EMPRESTADOS}): utilização mínima de ${SAT_USO_MINIMO_PCT}% dos jogos, salário pago por ti, regresso no fim da época.</div>
    <div style="overflow-x:auto;"><table class="data-table" style="width:100%;font-size:12px;"><thead><tr><th>Jogador</th><th>Idade</th><th>OVR</th><th>Rendimento</th><th></th></tr></thead><tbody>${linhasEmp}</tbody></table></div>
    <div style="display:flex;gap:6px;flex-wrap:wrap;align-items:center;margin:8px 0;">
      <select id="satEmpSel" ${opcoesEmp ? "" : "disabled"}>${opcoesEmp || "<option>Sem jovens elegíveis</option>"}</select>
      <button class="btn btn-ghost sat-emprestar" ${opcoesEmp ? "" : "disabled"}>Emprestar ao satélite</button></div>
    <div class="helptext" style="margin:8px 0 4px;">Jovens do satélite${a.preferencia ? ` (preferência com ${Math.round((1 - satDesconto(a)) * 100)}% de desconto sobre o valor de mercado; um por época, só na janela de inscrições)` : " (o acordo não inclui preferência)"}:</div>
    <div style="overflow-x:auto;"><table class="data-table" style="width:100%;font-size:12px;"><thead><tr><th>Jogador</th><th>Idade</th><th>OVR</th><th>Preço</th><th></th></tr></thead><tbody>${linhasProsp}</tbody></table></div>`;
}
document.addEventListener("click", (e) => {
  const t = e.target; if(!t || !t.closest) return;
  const redraw = () => { if(typeof renderDirectionPanel === "function") renderDirectionPanel(); };
  const msg = (r, ok) => showTransientNotice(r.ok ? ok : r.reason);
  if(t.closest(".sat-propor")){
    const sel = document.getElementById("satSel"), ap = document.getElementById("satApoioSel"), pf = document.getElementById("satPrefChk");
    if(!sel || !sel.value) return;
    const r = satPropor(sel.value, parseInt(ap.value, 10) || 0, !!(pf && pf.checked));
    msg(r, `Proposta enviada. Resposta em cerca de ${r.dias} dias.`); redraw(); return;
  }
  if(t.closest(".sat-terminar")){ msg(satTerminar(), "Acordo terminado."); redraw(); return; }
  if(t.closest(".sat-apoio")){ const ap = document.getElementById("satApoioMud"); msg(satMudarApoio(parseInt(ap.value, 10) || 0), "Apoio atualizado."); redraw(); return; }
  if(t.closest(".sat-emprestar")){ const sel = document.getElementById("satEmpSel"); if(!sel || !sel.value) return; msg(satEmprestar(sel.value), "Jogador emprestado ao satélite."); redraw(); return; }
  const ch = t.closest(".sat-chamar");
  if(ch){ msg(empChamarDeVolta(ch.getAttribute("data-id")), "Jogador chamado de volta."); redraw(); return; }
  const co = t.closest(".sat-contratar");
  if(co){ msg(satContratar(co.getAttribute("data-id")), "Jogador contratado ao abrigo da preferência."); redraw(); }
});
