  // ============================= 10-estatisticas.js =============================
  // Classificações, jornadas, equipas e estatísticas (render)
  // Standings / Fixtures / Teams / Stats rendering
  // =================================================================
  function standingsQuotient(gm, gs){
    if(gs>0) return gm/gs;
    return gm>0 ? Number.POSITIVE_INFINITY : 0;
  }

  function playedFixturesBetween(teamIds){
    const ids = new Set(teamIds);
    return state.fixtures.flat().filter(f=>f.played && ids.has(f.home) && ids.has(f.away));
  }

  function restrictedStandings(teams){
    const table = new Map(teams.map(t=>[t.id,{ pts:0, gm:0, gs:0 }]));
    playedFixturesBetween(teams.map(t=>t.id)).forEach(f=>{
      const home = table.get(f.home), away = table.get(f.away);
      home.gm += f.homeScore; home.gs += f.awayScore;
      away.gm += f.awayScore; away.gs += f.homeScore;
      if(f.homeScore>f.awayScore) home.pts += 3;
      else if(f.awayScore>f.homeScore) away.pts += 3;
      else { home.pts += 1; away.pts += 1; }
    });
    return table;
  }

  function splitByCriterion(teams, valueFn){
    const ordered = teams.slice().sort((a,b)=>valueFn(b)-valueFn(a));
    const groups = [];
    ordered.forEach(team=>{
      const value = valueFn(team);
      const last = groups[groups.length-1];
      if(!last || last.value!==value) groups.push({ value, teams:[team] });
      else last.teams.push(team);
    });
    return groups.map(g=>g.teams);
  }

  function sortTwoTeamTie(teams){
    const direct = restrictedStandings(teams);
    const criteria = [
      t=>direct.get(t.id).pts,
      t=>direct.get(t.id).gm-direct.get(t.id).gs,
      t=>t.stats.GM-t.stats.GS,
      t=>standingsQuotient(t.stats.GM,t.stats.GS),
    ];
    let groups = [teams];
    criteria.forEach(fn=>{
      groups = groups.flatMap(group=>group.length>1 ? splitByCriterion(group,fn) : [group]);
    });
    return groups.flatMap(group=>group.slice().sort((a,b)=>a.name.localeCompare(b.name,'pt')));
  }

  function sortMultiTeamTie(teams){
    const direct = restrictedStandings(teams);
    const firstCriteria = [
      t=>direct.get(t.id).pts,
      t=>direct.get(t.id).gm-direct.get(t.id).gs,
      t=>t.stats.GM-t.stats.GS,
    ];
    let groups = [teams];
    firstCriteria.forEach(fn=>{
      groups = groups.flatMap(group=>group.length>1 ? splitByCriterion(group,fn) : [group]);
    });
    groups = groups.flatMap(group=>{
      if(group.length<=1) return [group];
      if(group.length===2) return [sortTwoTeamTie(group)];
      const remainingDirect = restrictedStandings(group);
      return splitByCriterion(group,t=>{
        const r=remainingDirect.get(t.id);
        return standingsQuotient(r.gm,r.gs);
      });
    });
    groups = groups.flatMap(group=>group.length>1
      ? splitByCriterion(group,t=>standingsQuotient(t.stats.GM,t.stats.GS))
      : [group]);
    return groups.flatMap(group=>group.slice().sort((a,b)=>a.name.localeCompare(b.name,'pt')));
  }

  function displayedCompetitionId(){ return state.viewedCompetitionId || state.userCompetitionId; }
  function competitionTeams(competitionId){
    const comp=state.competitions[competitionId||displayedCompetitionId()];
    return comp ? comp.teamIds.map(id=>state.teams[id]).filter(Boolean) : [];
  }
  function sortedStandings(){
    const byPoints = new Map();
    competitionTeams().forEach(team=>{
      const pts=team.stats.Pts;
      if(!byPoints.has(pts)) byPoints.set(pts,[]);
      byPoints.get(pts).push(team);
    });
    return Array.from(byPoints.keys()).sort((a,b)=>b-a).flatMap(pts=>{
      const tied=byPoints.get(pts);
      if(tied.length===1) return tied;
      return tied.length===2 ? sortTwoTeamTie(tied) : sortMultiTeamTie(tied);
    });
  }
  function standingsForCompetition(competitionId){
    // NOTA (encontrado durante os testes da Fase 15): sortedStandings() lê competitionTeams()
    // que prioriza state.viewedCompetitionId sobre state.userCompetitionId — sem também
    // substituir viewedCompetitionId aqui, esta função devolvia sempre a tabela da competição
    // visualizada (normalmente o Placard) em vez da competição pedida, partindo a liguilha de
    // promoção Norte/Sul e a atribuição de subidas/descidas em praticamente qualquer jogo real.
    const previousUser=state.userCompetitionId, previousViewed=state.viewedCompetitionId;
    state.userCompetitionId=competitionId; state.viewedCompetitionId=competitionId;
    const result=sortedStandings().slice();
    state.userCompetitionId=previousUser; state.viewedCompetitionId=previousViewed;
    return result;
  }

  // Vista completa e independente da Taça de Portugal — pedido explícito: tem de ser uma
  // competição visível por si só, não só um cartão secundário dentro de outra. Mostra o quadro
  // completo (todas as eliminatórias já disputadas ou por disputar em cada fase), não só o
  // percurso do clube do utilizador. Reaproveita a aba "Playoff" (já totalmente dinâmica, sem
  // estrutura fixa a preservar) como área principal, e simplifica as restantes abas (que não
  // fazem sentido para uma prova de eliminação direta sem classificação).
  // Mesmo formato visual das jornadas das divisões (linhas .jr-row), não texto corrido — pedido
  // explícito. Sem posição na tabela (a Taça não tem classificação), mas com a mesma estrutura
  // de equipa/marcador/equipa, e a data da eliminatória.
  function tacaFaseHtml(fase){
    const tp = state.tacaPortugal;
    const jogos = tp.jogos[fase]||[];
    if(!jogos.length) return "";
    const data = jogos[0].date ? fmtDateShort(jogos[0].date) : "";
    const linhas = jogos.map(j=>{
      const marcador = j.played ? `${j.homeScore} - ${j.awayScore}${j.soWinner?' <span style="font-size:9px;">(g.p.)</span>':''}` : "—";
      const envolveUtilizador = j.home===state.userTeamId || j.away===state.userTeamId;
      return `<div class="jr-row ${envolveUtilizador?'jr-me':''}">
        <span class="jr-pos"></span>
        <button class="jr-team-link jr-home" data-team="${j.home}">${state.teams[j.home].name}</button>
        <span class="jr-score">${marcador}</span>
        <button class="jr-team-link jr-away" data-team="${j.away}">${state.teams[j.away].name}</button>
        <span class="jr-pos"></span>
      </div>`;
    }).join("");
    return `<div class="eyebrow" style="margin:14px 0 6px;">${TACA_FASE_LABEL[fase]}${data?` — ${data}`:''}${jogos.every(j=>j.played)?' — concluída':''}</div>
      ${linhas}`;
  }
  function renderTacaPortugalStandalone(){
    const tp = state.tacaPortugal;
    const meta=document.getElementById("competitionViewMeta");
    if(meta) meta.textContent = tp ? `${tacaEligibleTeams().length} clubes elegíveis · eliminação direta, todas as divisões · fase atual: ${tp.fase==="concluida"?"concluída":TACA_FASE_LABEL[tp.fase].replace('Taça de Portugal — ','')}` : "";
    ["standingsBody","statsGrid","teamsBody"].forEach(id=>{
      const el=document.getElementById(id);
      if(el) el.innerHTML = '<tr><td colspan="10" style="padding:16px;color:var(--texto-mute);font-size:12px;">A Taça de Portugal não tem classificação — é uma prova de eliminação direta. Vê o quadro completo em "Calendário & Resultados".</td></tr>';
    });
    const teamsBody = document.getElementById("teamsBody");
    if(teamsBody) teamsBody.innerHTML = '<p style="padding:16px;color:var(--texto-mute);font-size:12px;">A Taça de Portugal não tem classificação — é uma prova de eliminação direta. Vê o quadro completo em "Calendário & Resultados".</p>';
    const playoffTab = document.getElementById("tabPlayoff");
    if(playoffTab) playoffTab.innerHTML = '<p class="helptext">A Taça de Portugal é uma prova de eliminação direta e não tem playoff próprio — vê o quadro completo em "Calendário & Resultados".</p>';
    // Pedido explícito: as eliminatórias da Taça mostram-se em "Calendário & Resultados", não em
    // "Playoff" (essa aba é para o playoff do Placard e para as ligas de apuramento).
    const fixturesBody = document.getElementById("fixturesBody");
    if(fixturesBody){
      if(!tp){
        fixturesBody.innerHTML = '<p class="helptext">A Taça de Portugal ainda não foi sorteada esta época.</p>';
      } else {
        const campeaoHtml = tp.fase==="concluida" ? `<div class="info-banner" style="margin-bottom:8px;"><div style="font-size:13px;font-weight:700;color:var(--verde-ok);">🏆 Campeão da Taça de Portugal ${seasonLabel(state.season)}: ${teamLinkHtml(tp.campeao)}</div></div>` : "";
        const todasAsFases = TACA_FASES.slice().reverse().map(tacaFaseHtml).join("");
        fixturesBody.innerHTML = '<p class="helptext">Eliminação direta a uma só mão, aberta a todas as divisões. Os nomes a negrito são os jogos do teu clube.</p>' + campeaoHtml + todasAsFases;
      }
    }
    // Muda automaticamente para a aba Calendário & Resultados, que é onde está o conteúdo
    // relevante desta competição — sem isto, o utilizador veria as outras abas vazias por omissão.
    document.querySelectorAll(".tab-btn").forEach(b=>b.classList.toggle("active", b.getAttribute("data-tab")==="tabFixtures"));
    document.querySelectorAll(".tab-content").forEach(t=>t.classList.toggle("active", t.id==="tabFixtures"));
  }
  // Separador "Calendário": todos os jogos do próprio clube (liga + Taça de Portugal, que são
  // os que têm data fixa desde já) numa só lista cronológica, ao estilo Championship
  // Manager — data, adversário, local (casa/fora/neutro), competição, resultado.
  // Nota: os jogos de playoff/apuramento não têm data marcada com antecedência (só se sabe a
  // data do próximo jogo à medida que a série avança), por isso não entram aqui para já.
  function myFullSchedule(){
    const uid = state.userTeamId;
    const rows = [];
    const myComp = state.competitions[state.userCompetitionId];
    if(myComp){
      myComp.fixtures.forEach(round=>{
        const fx = round.find(f=>f.home===uid||f.away===uid);
        if(!fx) return;
        const isHome = fx.home===uid;
        rows.push({
          date: round.date, competicao: competitionLabel(myComp.id), oppId: isHome?fx.away:fx.home,
          local: isHome?"C":"F", played: fx.played,
          meu: fx.played?(isHome?fx.homeScore:fx.awayScore):null,
          seu: fx.played?(isHome?fx.awayScore:fx.homeScore):null,
          soWinner: fx.soWinner,
        });
      });
    }
    if(state.supertaca && state.supertaca.jogo && state.supertaca.jogo.date && (state.supertaca.jogo.home===uid || state.supertaca.jogo.away===uid)){
      const j = state.supertaca.jogo, isHome = j.home===uid;
      rows.push({
        date: j.date, competicao: "Supertaça António Livramento",
        oppId: isHome?j.away:j.home, local: "N", played: j.played,
        meu: j.played?(isHome?j.homeScore:j.awayScore):null,
        seu: j.played?(isHome?j.awayScore:j.homeScore):null,
        soWinner: j.soWinner,
      });
    }
    if(state.tacaPortugal){
      TACA_FASES.forEach(fase=>{
        (state.tacaPortugal.jogos[fase]||[]).forEach(j=>{
          // Correção (2026-09-16): uma eliminatória ainda por agendar guarda date:null até ao
          // sorteio/marcação — mostrar essa linha aqui só produzia uma data "undefined".
          if(!j.date || (j.home!==uid && j.away!==uid)) return;
          const isHome = j.home===uid;
          const isFinalFour = fase==="meiafinal"||fase==="final";
          rows.push({
            date: j.date, competicao: `Taça de Portugal — ${TACA_FASE_LABEL[fase].replace('Taça de Portugal — ','')}`,
            oppId: isHome?j.away:j.home, local: isFinalFour?"N":(isHome?"C":"F"), played: j.played,
            meu: j.played?(isHome?j.homeScore:j.awayScore):null,
            seu: j.played?(isHome?j.awayScore:j.homeScore):null,
            soWinner: j.soWinner,
          });
        });
      });
    }
    rows.push(...otherCompetitionsScheduleRows());
    rows.sort((a,b)=>new Date(a.date)-new Date(b.date));
    return rows;
  }
  // Correção (pedido do utilizador, 2026-09-12): "Calendário & Resultados" e o "Próximo jogo" do
  // Centro do Clube só conheciam a liga do utilizador + Taça de Portugal + Supertaça — qualquer
  // jogo de Elite Cup, Copa del Rey/Coppa Italia, Supercopa de España, Supercoppa Italiana ou das
  // provas europeias (Champions/Cup/Trophy/Ronda de Qualificação) do próprio clube do utilizador
  // ficava invisível em ambos os sítios (o utilizador via um jogo da Champions League a decorrer
  // e nem o calendário nem a contagem de dias sabiam dele). Função partilhada — usada aqui para
  // preencher o calendário completo, e por renderHubDate (09-fluxo-epoca.js) para saber qual é
  // mesmo o próximo jogo, seja de que prova for.
  function otherCompetitionsScheduleRows(){
    const uid = state.userTeamId;
    const rows = [];
    const pushRow = (j, competicao, local) => {
      if(!j || !j.date || (j.home!==uid && j.away!==uid)) return;
      const isHome = j.home===uid;
      rows.push({
        date: j.date, competicao,
        oppId: isHome?j.away:j.home, local: local!=null?local:(isHome?"C":"F"), played: !!j.played,
        meu: j.played?(isHome?j.homeScore:j.awayScore):null,
        seu: j.played?(isHome?j.awayScore:j.homeScore):null,
        soWinner: j.soWinner,
      });
    };
    if(state.eliteCup && state.eliteCup.edicao){
      const edicao = state.eliteCup.edicao;
      Object.keys(edicao.jogos||{}).forEach(fase=>{
        (edicao.jogos[fase]||[]).forEach(j=>pushRow(j, ELITE_CUP_FASE_LABEL[fase]||`Elite Cup — ${fase}`, "N"));
      });
    }
    if(typeof NATIONAL_CUP_CONFIG==="object"){
      Object.keys(NATIONAL_CUP_CONFIG).forEach(cupId=>{
        const cfg = NATIONAL_CUP_CONFIG[cupId];
        const edicao = state[cfg.stateField] && state[cfg.stateField].edicao;
        if(!edicao) return;
        Object.keys(edicao.jogos||{}).forEach(fase=>{
          const local = cfg.neutralQuartos && fase==="quartos" ? "N" : null;
          (edicao.jogos[fase]||[]).forEach(j=>pushRow(j, `${cfg.label} — ${NATIONAL_CUP_FASE_LABEL[fase]||fase}`, local));
        });
      });
    }
    if(state.supercopaEspana && state.supercopaEspana.edicao){
      const edicao = state.supercopaEspana.edicao;
      Object.keys(edicao.jogos||{}).forEach(fase=>{
        (edicao.jogos[fase]||[]).forEach(j=>pushRow(j, `Supercopa de España — ${fase==="final"?"Final":"Meia-Final"}`, "N"));
      });
    }
    if(state.supercoppaItaliana && state.supercoppaItaliana.jogo){
      const jogo = state.supercoppaItaliana.jogo;
      pushRow(jogo.leg1, "Supercoppa Italiana — 1ª Mão");
      pushRow(jogo.leg2, "Supercoppa Italiana — 2ª Mão");
    }
    const ed = state.europa && state.europa.edicao;
    if(ed){
      const scanGrupos = (grupos, label) => {
        (grupos||[]).forEach(g=>{
          (g.fixtures||[]).forEach(round=>{
            const fx = (round||[]).find(f=>f.home===uid||f.away===uid);
            if(fx) pushRow({...fx, date: round.date}, `${label} — ${g.nome}`);
          });
        });
      };
      scanGrupos(ed.qualificacao && ed.qualificacao.grupos, "Ronda de Qualificação Europeia");
      if(ed.champions && ed.champions.grupos) scanGrupos(ed.champions.grupos, "WSE Champions League");
      const scanBracket = (bracket) => {
        if(!bracket || !bracket.jogos) return;
        Object.keys(bracket.jogos).forEach(fase=>{
          (bracket.jogos[fase]||[]).forEach(tie=>{
            const legs = tie.legs||[];
            legs.forEach((leg,legIdx)=>{
              const sufixo = legs.length>1 ? (legIdx===0?" (1ª mão)":" (2ª mão)") : "";
              pushRow(leg, `${bracket.label} — ${EUROPA_FASE_LABEL[fase]||fase}${sufixo}`, tie.neutral?"N":null);
            });
          });
        });
      };
      scanBracket(ed.champions); scanBracket(ed.cup); scanBracket(ed.trophy);
    }
    return rows;
  }
  function renderCalendarioView(){
    const meta = document.getElementById("calendarioMeta");
    const body = document.getElementById("calendarioBody");
    if(!body) return;
    const rows = myFullSchedule();
    const extra = typeof calAmigLinhasCalendario==="function" ? calAmigLinhasCalendario() : [];
    const todos = rows.concat(extra).sort((a,b)=>new Date(a.date)-new Date(b.date));
    const jogados = todos.filter(r=>r.played).length;
    if(meta) meta.textContent = `${todos.length} jogos agendados · ${jogados} já disputados`;
    const localLabel = { C:"Casa", F:"Fora", N:"Neutro" };
    // Calendário mensal (08t-calendario.js): dias livres, propostas de amigáveis e quadrangulares.
    const topo = typeof calPainelHtml==="function" ? calPainelHtml() : "";
    let lista;
    if(!todos.length) lista = '<p class="helptext">Ainda não há jogos agendados.</p>';
    else lista = `<div style="display:grid;grid-template-columns:80px 1fr 32px 1.4fr 70px;gap:4px;font-size:11px;color:var(--texto-mute);font-weight:700;padding:4px 6px;border-bottom:1px solid rgba(255,255,255,0.1);">
          <div>Data</div><div>Adversário</div><div style="text-align:center;">Local</div><div>Competição</div><div style="text-align:center;">Resultado</div>
        </div>` + todos.map(r=>{
      const opp = state.teams[r.oppId];
      const resultado = r.played ? `${r.meu}-${r.seu}${r.soWinner?' (g.p.)':''}` : "—";
      const cor = !r.played ? "var(--texto-mute)" : (r.meu>r.seu ? "var(--verde-ok)" : r.meu<r.seu ? "var(--vermelho)" : "var(--texto-mute)");
      return `<div style="display:grid;grid-template-columns:80px 1fr 32px 1.4fr 70px;gap:4px;font-size:12px;padding:5px 6px;border-bottom:1px solid rgba(255,255,255,0.04);${r.played?'':'opacity:0.65;'}">
        <div>${fmtDateShort(r.date)}</div>
        <div><button class="jr-team-link" data-team="${r.oppId}">${opp?opp.name:'?'}</button></div>
        <div style="text-align:center;color:var(--texto-mute);">${localLabel[r.local]||r.local}</div>
        <div style="color:var(--texto-mute);">${r.competicao}</div>
        <div style="text-align:center;font-weight:700;color:${cor};">${resultado}</div>
      </div>`;
    }).join("");
    // Dois sub-separadores (como Equipa A/B no Plantel): vista mensal (grelha, marcar amigáveis,
    // convites e torneios) e vista geral (todos os jogos e resultados).
    const aba = typeof calUI!=="undefined" && calUI.aba==="geral" ? "geral" : "mensal";
    document.querySelectorAll("#calendarioTabs [data-cal-tab]").forEach(b=>b.classList.toggle("active", b.getAttribute("data-cal-tab")===aba));
    body.innerHTML = aba==="mensal" ? topo : `<div class="eyebrow section-label">Todos os jogos e resultados</div>` + lista;
  }
  // Vista da Supertaça António Livramento — jogo único, sem classificação nem playoff próprio,
  // seguindo o mesmo padrão de competição "virtual" (fora de state.competitions) já usado pela
  // Taça de Portugal, mostrado em "Calendário & Resultados" com o histórico de todas as edições.
  function renderSupertacaStandalone(){
    const s = state.supertaca, meta=document.getElementById("competitionViewMeta");
    if(meta) meta.textContent = "Jogo único, em campo neutro · campeão nacional vs. vencedor da Taça de Portugal da época anterior";
    ["standingsBody","statsGrid","teamsBody"].forEach(id=>{
      const el=document.getElementById(id);
      if(el) el.innerHTML = '<tr><td colspan="10" style="padding:16px;color:var(--texto-mute);font-size:12px;">A Supertaça António Livramento é um jogo único — não tem classificação. Vê o resultado e o histórico em "Calendário & Resultados".</td></tr>';
    });
    const teamsBody = document.getElementById("teamsBody");
    if(teamsBody) teamsBody.innerHTML = '<p style="padding:16px;color:var(--texto-mute);font-size:12px;">A Supertaça António Livramento é um jogo único — não tem classificação.</p>';
    const playoffTab = document.getElementById("tabPlayoff");
    if(playoffTab) playoffTab.innerHTML = '<p class="helptext">A Supertaça António Livramento é um jogo único, sem playoff próprio.</p>';
    const fixturesBody = document.getElementById("fixturesBody");
    if(fixturesBody){
      const jogoHtml = (j, destaque) => {
        const marcador = j.played ? `${j.homeScore} - ${j.awayScore}${j.soWinner?' <span style="font-size:9px;">(g.p.)</span>':''}` : "—";
        const envolveUtilizador = j.home===state.userTeamId || j.away===state.userTeamId;
        return `<div class="jr-row ${envolveUtilizador?'jr-me':''}">
          <span class="jr-pos"></span>
          <button class="jr-team-link jr-home" data-team="${j.home}">${state.teams[j.home]?state.teams[j.home].name:'?'}</button>
          <span class="jr-score">${marcador}</span>
          <button class="jr-team-link jr-away" data-team="${j.away}">${state.teams[j.away]?state.teams[j.away].name:'?'}</button>
          <span class="jr-pos"></span>
        </div>`;
      };
      let html = '<p class="helptext">Jogo único de pré-época, sempre em campo neutro (sem vantagem de jogar em casa). Os nomes a negrito são os jogos do teu clube.</p>';
      if(s && s.jogo){
        html += `<div class="eyebrow" style="margin:14px 0 6px;">Edição atual — ${s.jogo.seasonLabel||seasonLabel(s.jogo.epoca)}${s.jogo.date?` — ${fmtDateShort(new Date(s.jogo.date))}`:''}${s.jogo.played?' — concluída':''}</div>` + jogoHtml(s.jogo);
        if(s.jogo.played && s.jogo.vencedor){
          html = `<div class="info-banner" style="margin-bottom:8px;"><div style="font-size:13px;font-weight:700;color:var(--verde-ok);">🏆 Vencedor da Supertaça António Livramento ${s.jogo.seasonLabel||seasonLabel(s.jogo.epoca)}: ${state.teams[s.jogo.vencedor]?teamLinkHtml(s.jogo.vencedor):'?'}</div></div>` + html;
        }
      } else {
        html += '<p class="helptext">A Supertaça desta época ainda não foi emparelhada (ou não há dados de qualificação suficientes vindos da época anterior).</p>';
      }
      const historico = (s&&s.historico||[]).slice().sort((a,b)=>(b.epoca||0)-(a.epoca||0));
      if(historico.length){
        html += '<div class="eyebrow" style="margin:18px 0 6px;">Histórico de edições anteriores</div>' + historico.map(e=>{
          const vencedorNome = e.vencedor && state.teams[e.vencedor] ? teamLinkHtml(e.vencedor) : '?';
          return `<div class="eyebrow" style="margin:10px 0 4px;font-weight:400;">${e.seasonLabel||seasonLabel(e.epoca)} — 🏆 ${vencedorNome}</div>` + jogoHtml(e);
        }).join("");
      }
      fixturesBody.innerHTML = html;
    }
    document.querySelectorAll(".tab-btn").forEach(b=>b.classList.toggle("active", b.getAttribute("data-tab")==="tabFixtures"));
    document.querySelectorAll(".tab-content").forEach(t=>t.classList.toggle("active", t.id==="tabFixtures"));
  }
  // Vista da Elite Cup — quadro de 8, três fases (quartos/meias-finais/final), sempre em campo
  // neutro, seguindo o mesmo padrão "virtual" (fora de state.competitions) da Taça/Supertaça.
  // Mostra também, por baixo do quadro, o objetivo da direção do próprio clube nesta edição
  // (quando aplicável) — a única prova com este mecanismo, por isso não cabe no painel genérico
  // de Direção (04-financas.js).
  function eliteCupJogoHtml(j){
    const marcador = j.played ? `${j.homeScore} - ${j.awayScore}${j.soWinner?' <span style="font-size:9px;">(g.p.)</span>':''}` : "—";
    const envolveUtilizador = j.home===state.userTeamId || j.away===state.userTeamId;
    return `<div class="jr-row ${envolveUtilizador?'jr-me':''}">
      <span class="jr-pos"></span>
      <button class="jr-team-link jr-home" data-team="${j.home}">${state.teams[j.home]?state.teams[j.home].name:'?'}</button>
      <span class="jr-score">${marcador}</span>
      <button class="jr-team-link jr-away" data-team="${j.away}">${state.teams[j.away]?state.teams[j.away].name:'?'}</button>
      <span class="jr-pos"></span>
    </div>`;
  }
  function eliteCupObjectiveHtml(edicao){
    const obj = edicao && edicao.objetivos && edicao.objetivos[state.userTeamId];
    if(!obj) return "";
    const ajuste = obj.drawAdjustment>0?" (subido pelo sorteio)":obj.drawAdjustment<0?" (descido pelo sorteio)":"";
    let avaliacao = "";
    if(obj.evaluationImpact){
      const rotulo={superado:"Superado",cumprido:"Cumprido","falhado-uma-fase":"Falhado por uma fase","falhado-claramente":"Falhado claramente"}[obj.evaluationImpact.resultado]||obj.evaluationImpact.resultado;
      avaliacao = `<div style="margin-top:4px;">Avaliação da direção: <b>${rotulo}</b>${obj.evaluationImpact.atenuada?" (avaliação atenuada — contexto favorável)":""}</div>`;
    }
    return `<div class="info-banner" style="margin:10px 0;font-size:12px;">
      <div style="font-weight:700;">Objetivo da direção: ${ELITE_CUP_OBJECTIVE_LABEL[obj.objectiveLevel]}${ajuste}</div>
      ${avaliacao}
    </div>`;
  }
  function renderEliteCupStandalone(){
    const ec = state.eliteCup, edicao = ec && ec.edicao, meta=document.getElementById("competitionViewMeta");
    if(meta) meta.textContent = "8 clubes · eliminação direta a uma mão · sempre em campo neutro · prova de pré-época";
    ["standingsBody","statsGrid","teamsBody"].forEach(id=>{
      const el=document.getElementById(id);
      if(el) el.innerHTML = '<tr><td colspan="10" style="padding:16px;color:var(--texto-mute);font-size:12px;">A Elite Cup é uma eliminatória direta — não tem classificação. Vê o quadro e o histórico em "Calendário & Resultados".</td></tr>';
    });
    const teamsBody = document.getElementById("teamsBody");
    if(teamsBody) teamsBody.innerHTML = '<p style="padding:16px;color:var(--texto-mute);font-size:12px;">A Elite Cup é uma eliminatória direta — não tem classificação.</p>';
    const playoffTab = document.getElementById("tabPlayoff");
    if(playoffTab) playoffTab.innerHTML = '<p class="helptext">A Elite Cup não tem playoff próprio — é já, em si, uma eliminatória.</p>';
    const fixturesBody = document.getElementById("fixturesBody");
    if(fixturesBody){
      let html = '<p class="helptext">Prova de pré-época entre os 8 primeiros classificados do Campeonato Placard da época anterior, sempre em campo neutro (sem vantagem de jogar em casa). Os nomes a negrito são os jogos do teu clube.</p>';
      if(edicao){
        html += eliteCupObjectiveHtml(edicao);
        ["quartos","semifinal","final"].forEach(fase=>{
          const jogos = edicao.jogos[fase]||[];
          if(!jogos.length) return;
          html += `<div class="eyebrow" style="margin:14px 0 6px;">${ELITE_CUP_FASE_LABEL[fase].replace("Elite Cup — ","")}</div>` + jogos.map(eliteCupJogoHtml).join("");
        });
        if(edicao.fase==="concluida" && edicao.campeao){
          html = `<div class="info-banner" style="margin-bottom:8px;"><div style="font-size:13px;font-weight:700;color:var(--verde-ok);">🏆 Vencedor da Elite Cup ${edicao.seasonLabel||seasonLabel(edicao.epoca)}: ${state.teams[edicao.campeao]?teamLinkHtml(edicao.campeao):'?'}</div></div>` + html;
        }
      } else {
        html += '<p class="helptext">A Elite Cup desta época ainda não foi gerada (ou não há dados de qualificação suficientes vindos da época anterior).</p>';
      }
      const historico = (ec&&ec.historico||[]).slice().sort((a,b)=>(b.epoca||0)-(a.epoca||0)).filter(e=>!edicao||e.epoca!==edicao.epoca);
      if(historico.length){
        html += '<div class="eyebrow" style="margin:18px 0 6px;">Histórico de edições anteriores</div>' + historico.map(e=>{
          const vencedorNome = e.campeao && state.teams[e.campeao] ? teamLinkHtml(e.campeao) : '?';
          return `<div class="eyebrow" style="margin:10px 0 4px;font-weight:400;">${e.seasonLabel||seasonLabel(e.epoca)} — 🏆 ${vencedorNome}</div>` + (e.jogos.final||[]).map(eliteCupJogoHtml).join("");
        }).join("");
      }
      fixturesBody.innerHTML = html;
    }
    document.querySelectorAll(".tab-btn").forEach(b=>b.classList.toggle("active", b.getAttribute("data-tab")==="tabFixtures"));
    document.querySelectorAll(".tab-content").forEach(t=>t.classList.toggle("active", t.id==="tabFixtures"));
  }
  // Vista da Copa del Rey/Coppa Italia — mesmo padrão "virtual" (fora de state.competitions) da
  // Taça/Supertaça/Elite Cup, mas a meio da época (não em pré-época): quartos + meias-finais +
  // final, apurados pelos 8 primeiros da 1ª volta da OK Liga/Serie A1 (ver 07e-copas-nacionais.js).
  function nationalCupStandaloneMeta(cupId){
    return cupId==="copa-del-rey"
      ? "8 clubes · apurados pela 1ª volta da OK Liga · quartos, meias e final sempre em campo neutro (Final a Oito)"
      : "8 clubes · apurados pela 1ª volta da Serie A1 · quartos em casa do melhor classificado · meias e final em campo neutro (Final Four)";
  }
  function renderNationalCupStandalone(cupId){
    const cfg = NATIONAL_CUP_CONFIG[cupId];
    const container = state[cfg.stateField], edicao = container && container.edicao, meta=document.getElementById("competitionViewMeta");
    if(meta) meta.textContent = nationalCupStandaloneMeta(cupId);
    ["standingsBody","statsGrid","teamsBody"].forEach(id=>{
      const el=document.getElementById(id);
      if(el) el.innerHTML = `<tr><td colspan="10" style="padding:16px;color:var(--texto-mute);font-size:12px;">A ${cfg.label} é uma eliminatória direta — não tem classificação. Vê o quadro e o histórico em "Calendário &amp; Resultados".</td></tr>`;
    });
    const teamsBody = document.getElementById("teamsBody");
    if(teamsBody) teamsBody.innerHTML = `<p style="padding:16px;color:var(--texto-mute);font-size:12px;">A ${cfg.label} é uma eliminatória direta — não tem classificação.</p>`;
    const playoffTab = document.getElementById("tabPlayoff");
    if(playoffTab) playoffTab.innerHTML = `<p class="helptext">A ${cfg.label} não tem playoff próprio — é já, em si, uma eliminatória.</p>`;
    const fixturesBody = document.getElementById("fixturesBody");
    if(fixturesBody){
      let html = `<p class="helptext">Disputada a meio da época, entre os 8 primeiros classificados da 1ª volta. Os nomes a negrito são os jogos do teu clube.</p>`;
      if(edicao){
        ["quartos","semifinal","final"].forEach(fase=>{
          const jogos = edicao.jogos[fase]||[];
          if(!jogos.length) return;
          html += `<div class="eyebrow" style="margin:14px 0 6px;">${NATIONAL_CUP_FASE_LABEL[fase]}</div>` + jogos.map(eliteCupJogoHtml).join("");
        });
        if(edicao.fase==="concluida" && edicao.campeao){
          html = `<div class="info-banner" style="margin-bottom:8px;"><div style="font-size:13px;font-weight:700;color:var(--verde-ok);">🏆 Vencedor da ${cfg.label} ${edicao.seasonLabel||seasonLabel(edicao.epoca)}: ${state.teams[edicao.campeao]?teamLinkHtml(edicao.campeao):'?'}</div></div>` + html;
        }
      } else {
        html += `<p class="helptext">A ${cfg.label} desta época ainda não foi apurada (a 1ª volta da liga ainda não terminou).</p>`;
      }
      const historico = (container&&container.historico||[]).slice().sort((a,b)=>(b.epoca||0)-(a.epoca||0)).filter(e=>!edicao||e.epoca!==edicao.epoca);
      if(historico.length){
        html += '<div class="eyebrow" style="margin:18px 0 6px;">Histórico de edições anteriores</div>' + historico.map(e=>{
          const vencedorNome = e.campeao && state.teams[e.campeao] ? teamLinkHtml(e.campeao) : '?';
          return `<div class="eyebrow" style="margin:10px 0 4px;font-weight:400;">${e.seasonLabel||seasonLabel(e.epoca)} — 🏆 ${vencedorNome}</div>` + (e.jogos.final||[]).map(eliteCupJogoHtml).join("");
        }).join("");
      }
      fixturesBody.innerHTML = html;
    }
    document.querySelectorAll(".tab-btn").forEach(b=>b.classList.toggle("active", b.getAttribute("data-tab")==="tabFixtures"));
    document.querySelectorAll(".tab-content").forEach(t=>t.classList.toggle("active", t.id==="tabFixtures"));
  }
  // Vista das Seleções Nacionais (Mundial/Taça do Mundo e Europeu) — 2026-09-26. Ao contrário das
  // outras provas "standalone" desta secção, esta TEM classificação real (2 grupos de 4) — por
  // isso, ao contrário de renderEliteCupStandalone/renderNationalCupStandalone, não força a
  // troca para a aba "Calendário & Resultados" nem esconde a Classificação. As equipas virtuais
  // já foram apagadas de state.teams quando o torneio terminou (ver resolveSelecaoTournament,
  // 07h-selecoes.js) — toda esta vista lê só do arquivo em state.selecoesHistorico, nunca de
  // state.teams.
  function selecaoGroupStandingsRows(rows, letter){
    return `<tr><td colspan="10" style="font-weight:700;padding:10px 4px 4px;color:var(--texto-mute);font-size:12px;text-transform:uppercase;">Grupo ${letter}</td></tr>` +
      rows.map((r,idx)=>{
        const dg = r.GM-r.GS;
        return `<tr>
          <td class="num">${idx+1}</td>
          <td class="teamcell">${selecaoNationLinkHtml(r.code)}</td>
          <td class="num">${r.J}</td><td class="num">${r.V}</td><td class="num">${r.E}</td><td class="num">${r.D}</td>
          <td class="num">${r.GM}</td><td class="num">${r.GS}</td><td class="num">${dg>0?'+':''}${dg}</td>
          <td class="num"><b>${r.Pts}</b></td>
        </tr>`;
      }).join("");
  }
  function selecaoFinalPosLabelMap(ed){
    const map = {};
    (ed.groupStandingsA||[]).forEach((r,i)=>{ map[r.code] = (i+1)+"ºA"; });
    (ed.groupStandingsB||[]).forEach((r,i)=>{ map[r.code] = (i+1)+"ºB"; });
    return map;
  }
  function selecaoBracketSectionHtml(title, fixtures, posLabels){
    if(!fixtures || !fixtures.length) return "";
    return `<div class="eyebrow" style="margin:14px 0 6px;">${title}</div>` +
      fixtures.map(fx=>selecaoRowHtml(fx, true, (posLabels&&posLabels[fx.home])||"", (posLabels&&posLabels[fx.away])||"")).join("");
  }
  function selecaoEditionDetailHtml(ed){
    const posLabels = selecaoFinalPosLabelMap(ed);
    let html = `<div class="info-banner" style="margin-bottom:8px;"><div style="font-size:13px;font-weight:700;color:var(--verde-ok);">🏆 Campeão ${ed.seasonLabel||seasonLabel(ed.season)}: ${selecaoNationLinkHtml(ed.campeao)}</div>`+
      `<div style="font-size:12px;color:var(--texto-mute);margin-top:2px;">País organizador desta edição: ${selecaoNationLinkHtml(ed.hostCode)} (vantagem de jogar em casa)</div></div>`;
    (ed.fixturesA||[]).forEach((round,i)=>{
      html += `<div class="jornada-heading">Jornada ${i+1}</div>`+
        `<div class="jr-group-header">Grupo A</div>` + round.map(fx=>selecaoRowHtml(fx,true)).join("") +
        `<div class="jr-group-header">Grupo B</div>` + (ed.fixturesB&&ed.fixturesB[i]||[]).map(fx=>selecaoRowHtml(fx,true)).join("");
    });
    html += selecaoBracketSectionHtml("Quartos-de-final", ed.quartos, posLabels);
    html += selecaoBracketSectionHtml("Meias-finais", ed.meias);
    html += selecaoBracketSectionHtml("3º/4º lugar", ed.terceiro);
    html += selecaoBracketSectionHtml("Final", ed.final);
    return html;
  }
  // Correção (pedido explícito do utilizador, 2026-09-27: "o campeonato do mundo está a acontecer
  // e no separador das competições não consigo ver os grupos nem o calendário") — as duas funções
  // acima (selecaoGroupStandingsRows/selecaoEditionDetailHtml) e o comentário logo acima de
  // selecaoGroupStandingsRows dizem explicitamente que esta vista "lê só do arquivo em
  // state.selecoesHistorico, nunca de state.teams" — verdade enquanto o torneio inteiro se
  // resolvia numa única chamada síncrona (a edição já estava arquivada antes de o utilizador
  // sequer poder abrir esta aba). Desde a revelação diária (processSelecoesForCurrentDate,
  // 07h-selecoes.js), o torneio fica "em curso" (state.selecoes.edicao, equipas virtuais vivas em
  // state.teams) durante vários dias reais ANTES de ser arquivado — e esta vista não tinha
  // nenhuma leitura desse estado ao vivo, mostrando sempre "ainda não houve nenhuma edição" até a
  // final terminar. Estas duas funções fazem o equivalente ao vivo: classificação lida
  // diretamente de state.teams[selecaoVirtualTeamId(code)].stats (sempre existe desde
  // prepareSelecoesEdicaoForNewSeason, mesmo com 0 jogos) e calendário lido diretamente de
  // ed.fixturesA/fixturesB/qfFixtures/sfFixtures/thirdFixtures/finalFixtures (cada fase só existe
  // depois de resolvida — mostra-se só o que já foi gerado).
  function selecaoLiveGroupStandingsRows(ed){
    const rowsFor = codes => codes.map(code=>{
      const st = state.teams[selecaoVirtualTeamId(code)].stats;
      return { code, J:st.J, V:st.V, E:st.E, D:st.D, GM:st.GM, GS:st.GS, Pts:st.Pts };
    });
    return selecaoGroupStandingsRows(rowsFor(sortSelecaoGroupCodes(ed.groupA)),"A") +
      selecaoGroupStandingsRows(rowsFor(sortSelecaoGroupCodes(ed.groupB)),"B");
  }
  function selecaoLiveEditionDetailHtml(ed){
    let html = `<div class="info-banner" style="margin-bottom:8px;"><div style="font-size:13px;font-weight:700;color:var(--texto-mute);">🏳️ Torneio em curso — país organizador desta edição: ${selecaoNationLinkHtml(ed.hostCode)} (vantagem de jogar em casa)</div></div>`;
    ed.fixturesA.forEach((round,i)=>{
      html += `<div class="jornada-heading">Jornada ${i+1}</div>`+
        `<div class="jr-group-header">Grupo A</div>` + round.map(fx=>selecaoRowHtml(fx,true)).join("") +
        `<div class="jr-group-header">Grupo B</div>` + (ed.fixturesB[i]||[]).map(fx=>selecaoRowHtml(fx,true)).join("");
    });
    const posLabels = ed.seedLabels || {};
    if(ed.qfFixtures) html += selecaoBracketSectionHtml("Quartos-de-final", ed.qfFixtures, posLabels);
    if(ed.sfFixtures) html += selecaoBracketSectionHtml("Meias-finais", ed.sfFixtures);
    if(ed.thirdFixtures) html += selecaoBracketSectionHtml("3º/4º lugar", ed.thirdFixtures);
    if(ed.finalFixtures) html += selecaoBracketSectionHtml("Final", ed.finalFixtures);
    return html;
  }
  // Estatísticas e prémios (pedido explícito do utilizador, 2026-09-27: "também deve haver
  // estatísticas e prêmios nos mundiais e europeus") — reaproveita selecaoAwardEntries
  // (07h-selecoes.js) para uma tabela de melhores marcadores AO VIVO enquanto o torneio decorre
  // (ed.playerStats, acumulado jogo a jogo), e o snapshot já arquivado (topScorers/
  // premiosIndividuais) para uma edição já concluída. Um jogador que entretanto já não exista em
  // nenhum clube (raríssimo — reforma muito antiga) mostra-se só pelo nome, sem link.
  function selecaoHistoricoPlayerLinkHtml(teamId, playerId, fallbackName){
    const team = teamId ? state.teams[teamId] : null;
    const player = team && (team.players.find(x=>x.id===playerId) || (typeof findPlayerInAcademy==="function" ? findPlayerInAcademy(teamId, playerId) : null));
    return player ? playerLinkHtml(teamId, player) : escapeHtml(fallbackName||"—");
  }
  function selecaoStatsTableHtml(rows){
    return `<table class="stat-list" style="grid-column:1/-1;"><thead><tr><th>#</th><th>Jogador</th><th>Equipa</th><th class="num">J</th><th class="num">Golos</th><th class="num">Assist.</th></tr></thead><tbody>${rows}</tbody></table>`;
  }
  function selecaoStatsGridHtml(ed, latest){
    if(ed){
      const entries = (typeof selecaoAwardEntries==="function" ? selecaoAwardEntries(ed) : [])
        .slice().sort((a,b)=>(b.golos-a.golos)||((b.golos/Math.max(1,b.jogos))-(a.golos/Math.max(1,a.jogos)))||a.player.name.localeCompare(b.player.name,"pt")).slice(0,8);
      if(!entries.length) return `<p style="padding:16px;color:var(--texto-mute);font-size:12px;grid-column:1/-1;">Ainda sem golos registados nesta edição.</p>`;
      return selecaoStatsTableHtml(entries.map((e,idx)=>`<tr>
        <td class="num">${idx+1}</td><td>${playerLinkHtml(e.team.id,e.player)}</td><td>${teamLinkHtml(e.team.id)}</td>
        <td class="num">${e.jogos}</td><td class="num">${e.golos}</td><td class="num">${e.assistencias}</td>
      </tr>`).join(""));
    }
    if(latest && latest.topScorers && latest.topScorers.length){
      const pr = latest.premiosIndividuais;
      const premiosHtml = pr ? `<div class="eyebrow" style="margin:0 0 8px;grid-column:1/-1;">Prémios individuais — ${latest.seasonLabel||seasonLabel(latest.season)}</div>
        <div style="grid-column:1/-1;font-size:13px;line-height:1.8;margin-bottom:14px;">
          ${pr.marcador?`<div><b>Melhor Marcador:</b> ${selecaoHistoricoPlayerLinkHtml(pr.marcador.teamId,pr.marcador.playerId,pr.marcador.nome)} (${teamLinkHtml(pr.marcador.teamId)}) — ${pr.marcador.golos} golo(s)</div>`:""}
          ${pr.guardaRedes?`<div><b>Melhor Guarda-Redes:</b> ${selecaoHistoricoPlayerLinkHtml(pr.guardaRedes.teamId,pr.guardaRedes.playerId,pr.guardaRedes.nome)} (${teamLinkHtml(pr.guardaRedes.teamId)})</div>`:""}
          ${pr.jogador?`<div><b>Melhor Jogador:</b> ${selecaoHistoricoPlayerLinkHtml(pr.jogador.teamId,pr.jogador.playerId,pr.jogador.nome)} (${teamLinkHtml(pr.jogador.teamId)})</div>`:""}
        </div>` : "";
      return premiosHtml + selecaoStatsTableHtml(latest.topScorers.map((e,idx)=>`<tr>
        <td class="num">${idx+1}</td><td>${selecaoHistoricoPlayerLinkHtml(e.teamId,e.playerId,e.nome)}</td><td>${teamLinkHtml(e.teamId)}</td>
        <td class="num">${e.jogos}</td><td class="num">${e.golos}</td><td class="num">${e.assistencias||0}</td>
      </tr>`).join(""));
    }
    return `<p style="padding:16px;color:var(--texto-mute);font-size:12px;grid-column:1/-1;">Sem estatísticas agregadas para seleções ainda.</p>`;
  }
  function renderSelecoesStandalone(prova){
    const meta = document.getElementById("competitionViewMeta");
    if(meta) meta.textContent = (selecaoProvaIsS19(prova) ? "Sub-19 · jovens dos plantéis A/B e da academia · " : "") + "8 seleções · 2 grupos de 4 por classificação · todas avançam a quartos-de-final · prova não jogável (só resultados)";
    // Ao contrário de uma liga normal, aqui NINGUÉM é despromovido nem eliminado pela fase de
    // grupos — a posição só decide o emparelhamento dos quartos-de-final (1ºA-4ºB, etc.). A
    // legenda-padrão (playoff/despromoção) seria enganadora, por isso é substituída por uma
    // própria enquanto esta vista estiver ativa (reposta por renderCompetitionView ao sair).
    const standingsLegendEl = document.getElementById("standingsLegend");
    if(standingsLegendEl) standingsLegendEl.innerHTML = `
        <div class="leg-item"><span class="leg-swatch" style="background:#3FA34D;"></span> Grupo A · as 4 seleções melhor rankeadas</div>
        <div class="leg-item"><span class="leg-swatch" style="background:var(--texto-mute);"></span> Grupo B · as restantes 4 — todas as 8 avançam a quartos-de-final</div>`;
    const isS19 = selecaoProvaIsS19(prova);
    const edCand = state.selecoes && (isS19 ? state.selecoes.edicaoS19 : state.selecoes.edicao);
    const ed = (edCand && edCand.prova===prova) ? edCand : null;
    const historico = (state.selecoesHistorico||[]).filter(e=>e.prova===prova).sort((a,b)=>b.season-a.season);
    const latest = historico[0];
    const standingsBody = document.getElementById("standingsBody");
    if(standingsBody){
      standingsBody.innerHTML = ed
        ? selecaoLiveGroupStandingsRows(ed)
        : (latest
          ? selecaoGroupStandingsRows(latest.groupStandingsA,"A") + selecaoGroupStandingsRows(latest.groupStandingsB,"B")
          : `<tr><td colspan="10" style="padding:16px;color:var(--texto-mute);font-size:12px;">Ainda não houve nenhuma edição desta prova nesta carreira. ${isS19 ? (prova==="mundial-s19"?"O Mundial Sub-19 disputa-se de 10 a 15 de setembro, imediatamente antes do Mundial sénior.":"O Europeu Sub-19 disputa-se de 26 a 31 de agosto, imediatamente antes do Europeu sénior (alterna com o Mundial, época sim, época não).") : (prova==="mundial"?"O Mundial é sempre a 1ª edição de seleções da carreira, disputada no início da 2ª época.":"O Europeu segue-se ao Mundial, na 2ª edição de seleções da carreira.")}</td></tr>`);
    }
    const statsGrid = document.getElementById("statsGrid");
    if(statsGrid) statsGrid.innerHTML = selecaoStatsGridHtml(ed, latest);
    const teamsBody = document.getElementById("teamsBody");
    if(teamsBody) teamsBody.innerHTML = `<p style="padding:16px;color:var(--texto-mute);font-size:12px;">As seleções só são convocadas durante a janela do torneio — não têm plantel permanente para consultar aqui.</p>`;
    const playoffTab = document.getElementById("tabPlayoff");
    if(playoffTab) playoffTab.innerHTML = `<p class="helptext">As eliminatórias desta prova (quartos, meias, final e 3º/4º lugar) estão na aba "Calendário &amp; Resultados", a seguir à fase de grupos.</p>`;
    const fixturesBody = document.getElementById("fixturesBody");
    if(fixturesBody){
      let html = `<p class="helptext">${selecaoCompetitionName(prova)} — 2 grupos de 4 seleções por classificação (Grupo A = melhor rankeadas), todas-contra-todas dentro do grupo, depois todas as 8 avançam a quartos-de-final (cruzamento 1ºA-4ºB / 2ºA-3ºB / 1ºB-4ºA / 2ºB-3ºA). Prova não jogável — o teu clube só é afetado se algum jogador teu for convocado, ficando indisponível durante a janela do torneio.</p>`;
      html += ed ? selecaoLiveEditionDetailHtml(ed) : (latest ? selecaoEditionDetailHtml(latest) : `<p class="helptext">Esta prova ainda não foi disputada nesta carreira.</p>`);
      // Histórico completo de vencedores/vencidos/organizadores (pedido explícito do
      // utilizador, 2026-09-27, com um exemplo da Wikipédia do Europeu real — "tambem tem de se
      // fazer o historico dos vencedores, vencidos e organizadores no historico da competição...
      // não copiar formatação deste exemplo"): tabela com uma linha por edição já concluída,
      // numerada por ordem cronológica (Ed. I = 1ª edição desta prova na carreira), com a época,
      // o país organizador e os 4 primeiros classificados — tudo já vem de
      // state.selecoesHistorico (campeao/finalista/terceiro_lugar/quarto/hostCode), nunca
      // recalculado aqui. Não inclui a edição em curso (ed) — essa ainda não tem vencedor.
      if(historico.length){
        const historicoAsc = historico.slice().reverse();
        html += `<div class="eyebrow" style="margin:18px 0 6px;">Histórico de edições</div>
          <div style="overflow-x:auto;"><table class="stat-list"><thead><tr>
            <th>Ed.</th><th>Época</th><th>Organizador</th><th>Vencedor</th><th>2º lugar</th><th>3º lugar</th><th>4º lugar</th>
          </tr></thead><tbody>${historicoAsc.map((e,idx)=>`<tr>
            <td class="num">${idx+1}</td>
            <td>${escapeHtml(e.seasonLabel||seasonLabel(e.season))}</td>
            <td>${selecaoNationLinkHtml(e.hostCode)}</td>
            <td>${selecaoNationLinkHtml(e.campeao)}</td>
            <td>${selecaoNationLinkHtml(e.finalista)}</td>
            <td>${selecaoNationLinkHtml(e.terceiro_lugar)}</td>
            <td>${selecaoNationLinkHtml(e.quarto)}</td>
          </tr>`).join("")}</tbody></table></div>`;
      }
      fixturesBody.innerHTML = html;
    }
  }
  // Vista da Supercopa de España — Final Four de pré-época, 4 clubes fixos, campo neutro.
  function renderSupercopaEspanaStandalone(){
    const sc = state.supercopaEspana, edicao = sc && sc.edicao, meta=document.getElementById("competitionViewMeta");
    if(meta) meta.textContent = "4 clubes fixos (campeão+vice da OK Liga, vencedor+finalista da Copa del Rey) · Final Four de pré-época, sempre em campo neutro";
    ["standingsBody","statsGrid","teamsBody"].forEach(id=>{
      const el=document.getElementById(id);
      if(el) el.innerHTML = '<tr><td colspan="10" style="padding:16px;color:var(--texto-mute);font-size:12px;">A Supercopa de España é uma eliminatória direta — não tem classificação. Vê o quadro e o histórico em "Calendário &amp; Resultados".</td></tr>';
    });
    const teamsBody = document.getElementById("teamsBody");
    if(teamsBody) teamsBody.innerHTML = '<p style="padding:16px;color:var(--texto-mute);font-size:12px;">A Supercopa de España é uma eliminatória direta — não tem classificação.</p>';
    const playoffTab = document.getElementById("tabPlayoff");
    if(playoffTab) playoffTab.innerHTML = '<p class="helptext">A Supercopa de España não tem playoff próprio — é já, em si, uma eliminatória.</p>';
    const fixturesBody = document.getElementById("fixturesBody");
    if(fixturesBody){
      let html = '<p class="helptext">Disputada em pré-época, na 1ª semana de outubro, sempre em campo neutro. Os nomes a negrito são os jogos do teu clube.</p>';
      if(edicao){
        ["semifinal","final"].forEach(fase=>{
          const jogos = edicao.jogos[fase]||[];
          if(!jogos.length) return;
          html += `<div class="eyebrow" style="margin:14px 0 6px;">${fase==="final"?"Final":"Meias-Finais"}</div>` + jogos.map(eliteCupJogoHtml).join("");
        });
        if(edicao.fase==="concluida" && edicao.campeao){
          html = `<div class="info-banner" style="margin-bottom:8px;"><div style="font-size:13px;font-weight:700;color:var(--verde-ok);">🏆 Vencedor da Supercopa de España ${edicao.seasonLabel||seasonLabel(edicao.epoca)}: ${state.teams[edicao.campeao]?teamLinkHtml(edicao.campeao):'?'}</div></div>` + html;
        }
      } else {
        html += '<p class="helptext">A Supercopa de España desta época ainda não foi emparelhada (ou não há dados de qualificação suficientes vindos da época anterior).</p>';
      }
      const historico = (sc&&sc.historico||[]).slice().sort((a,b)=>(b.epoca||0)-(a.epoca||0)).filter(e=>!edicao||e.epoca!==edicao.epoca);
      if(historico.length){
        html += '<div class="eyebrow" style="margin:18px 0 6px;">Histórico de edições anteriores</div>' + historico.map(e=>{
          const vencedorNome = e.campeao && state.teams[e.campeao] ? teamLinkHtml(e.campeao) : '?';
          return `<div class="eyebrow" style="margin:10px 0 4px;font-weight:400;">${e.seasonLabel||seasonLabel(e.epoca)} — 🏆 ${vencedorNome}</div>` + (e.jogos.final||[]).map(eliteCupJogoHtml).join("");
        }).join("");
      }
      fixturesBody.innerHTML = html;
    }
    document.querySelectorAll(".tab-btn").forEach(b=>b.classList.toggle("active", b.getAttribute("data-tab")==="tabFixtures"));
    document.querySelectorAll(".tab-content").forEach(t=>t.classList.toggle("active", t.id==="tabFixtures"));
  }
  // Vista da Supercoppa Italiana — só 2 clubes, eliminatória a duas mãos (andata/ritorno), cada
  // mão em casa de um dos dois clubes (ao contrário da Supertaça portuguesa e da Supercopa de
  // España, que são sempre em campo neutro).
  function renderSupercoppaItalianaStandalone(){
    const si = state.supercoppaItaliana, jogo = si && si.jogo, meta=document.getElementById("competitionViewMeta");
    if(meta) meta.textContent = "2 clubes (campeão da Serie A1 vs. vencedor da Coppa Italia) · eliminatória a duas mãos, em casa de cada um";
    ["standingsBody","statsGrid","teamsBody"].forEach(id=>{
      const el=document.getElementById(id);
      if(el) el.innerHTML = '<tr><td colspan="10" style="padding:16px;color:var(--texto-mute);font-size:12px;">A Supercoppa Italiana é uma eliminatória a duas mãos — não tem classificação. Vê o resultado e o histórico em "Calendário &amp; Resultados".</td></tr>';
    });
    const teamsBody = document.getElementById("teamsBody");
    if(teamsBody) teamsBody.innerHTML = '<p style="padding:16px;color:var(--texto-mute);font-size:12px;">A Supercoppa Italiana é uma eliminatória a duas mãos — não tem classificação.</p>';
    const playoffTab = document.getElementById("tabPlayoff");
    if(playoffTab) playoffTab.innerHTML = '<p class="helptext">A Supercoppa Italiana não tem playoff próprio — é já, em si, uma eliminatória.</p>';
    const fixturesBody = document.getElementById("fixturesBody");
    if(fixturesBody){
      let html = '<p class="helptext">Eliminatória a duas mãos (novembro/dezembro), cada mão em casa de um dos dois clubes. Os nomes a negrito são os jogos do teu clube.</p>';
      const legHtml = (leg,label) => leg ? `<div class="eyebrow" style="margin:14px 0 6px;">${label}</div>` + eliteCupJogoHtml(leg) : "";
      if(jogo){
        html += legHtml(jogo.leg1, "1ª mão") + legHtml(jogo.leg2, "2ª mão");
        if(jogo.concluida && jogo.vencedor){
          html = `<div class="info-banner" style="margin-bottom:8px;"><div style="font-size:13px;font-weight:700;color:var(--verde-ok);">🏆 Vencedor da Supercoppa Italiana ${jogo.seasonLabel||seasonLabel(jogo.epoca)}: ${state.teams[jogo.vencedor]?teamLinkHtml(jogo.vencedor):'?'}</div></div>` + html;
        }
      } else {
        html += '<p class="helptext">A Supercoppa Italiana desta época ainda não foi emparelhada (ou não há dados de qualificação suficientes vindos da época anterior).</p>';
      }
      const historico = (si&&si.historico||[]).slice().sort((a,b)=>(b.epoca||0)-(a.epoca||0)).filter(e=>!jogo||e.epoca!==jogo.epoca);
      if(historico.length){
        html += '<div class="eyebrow" style="margin:18px 0 6px;">Histórico de edições anteriores</div>' + historico.map(e=>{
          const vencedorNome = e.vencedor && state.teams[e.vencedor] ? teamLinkHtml(e.vencedor) : '?';
          return `<div class="eyebrow" style="margin:10px 0 4px;font-weight:400;">${e.seasonLabel||seasonLabel(e.epoca)} — 🏆 ${vencedorNome}</div>` + legHtml(e.leg1,"1ª mão") + legHtml(e.leg2,"2ª mão");
        }).join("");
      }
      fixturesBody.innerHTML = html;
    }
    document.querySelectorAll(".tab-btn").forEach(b=>b.classList.toggle("active", b.getAttribute("data-tab")==="tabFixtures"));
    document.querySelectorAll(".tab-content").forEach(t=>t.classList.toggle("active", t.id==="tabFixtures"));
  }
  // ---- Competições Europeias (07g-europa.js) — vistas "virtuais", fora de state.competitions,
  // no mesmo espírito das restantes provas acima (Taça/Elite Cup/Copas nacionais). ----
  function europaLegHtml(leg, label){
    const marcador = leg.played ? `${leg.homeScore} - ${leg.awayScore}${leg.soWinner?' <span style="font-size:9px;">(g.p.)</span>':''}` : "—";
    const envolveUtilizador = leg.home===state.userTeamId || leg.away===state.userTeamId;
    return `<div class="jr-row ${envolveUtilizador?'jr-me':''}">
      <span class="jr-pos">${label||""}</span>
      <button class="jr-team-link jr-home" data-team="${leg.home}">${state.teams[leg.home]?state.teams[leg.home].name:'?'}</button>
      <span class="jr-score">${marcador}</span>
      <button class="jr-team-link jr-away" data-team="${leg.away}">${state.teams[leg.away]?state.teams[leg.away].name:'?'}</button>
      <span class="jr-pos"></span>
    </div>`;
  }
  function europaTieHtml(tie){
    if(tie.legs.length===1) return europaLegHtml(tie.legs[0], "");
    return europaLegHtml(tie.legs[0], "1ª mão") + europaLegHtml(tie.legs[1], "2ª mão");
  }
  // Correção (pedido do utilizador, 2026-09-12): a fase de grupos usava uma tabela "mesa-mini"
  // sem qualquer CSS dedicado (estilo em bruto do browser) — feia e inconsistente com a
  // classificação normal dos campeonatos. Passa a reutilizar exatamente a mesma marcação
  // (table.standings, teamcell com swatch de cor, jr-team-link clicável, linha do utilizador a
  // negrito) usada em renderStandings(), válido para qualquer competição com grupos. O parâmetro
  // opcional `advance` (quantos primeiros de cada grupo continuam em prova) pinta as zonas de
  // apuramento/eliminação tal como no campeonato — só faz sentido quando há eliminação real
  // dentro da própria prova (ex.: grupos da WSE Champions League, onde só os 4 primeiros de 6
  // seguem para os quartos); a Ronda de Qualificação não elimina ninguém (todos seguem para uma
  // das três provas), por isso não recebe zonas.
  function europaGroupTableHtml(grupo, opts){
    opts = opts || {};
    const advance = opts.advance || 0;
    const tabela = europaGroupStandings(grupo);
    const rows = tabela.map((row,i)=>{
      const team = state.teams[row.id];
      const dg = row.GM - row.GS;
      const isMe = row.id === state.userTeamId;
      const pos = i+1;
      const zone = advance ? (pos<=advance ? "zone-playoff" : "zone-relegation") : "";
      return `<tr class="${isMe?'me':''} ${zone}">
        <td class="num">${pos}</td>
        <td class="teamcell"><span class="swatch" style="background:${clubDisplayColor(team)};"></span>${team?teamLinkHtml(row.id):escapeHtml(row.id)}</td>
        <td class="num">${row.J}</td><td class="num">${row.V}</td><td class="num">${row.E}</td><td class="num">${row.D}</td>
        <td class="num">${row.GM}</td><td class="num">${row.GS}</td><td class="num">${dg>0?'+':''}${dg}</td>
        <td class="num"><b>${row.Pts}</b></td>
      </tr>`;
    }).join("");
    return `<div class="eyebrow" style="margin:14px 0 6px;">${grupo.nome}</div>
      <table class="standings" style="margin-bottom:16px;">
        <thead><tr>
          <th class="num">#</th><th>Equipa</th>
          <th class="num">J</th><th class="num">V</th><th class="num">E</th><th class="num">D</th>
          <th class="num">GM</th><th class="num">GS</th><th class="num">DG</th><th class="num">Pts</th>
        </tr></thead>
        <tbody>${rows}</tbody>
      </table>`;
  }
  function europaAttachTeamLinks(container){
    if(!container) return;
  }
  // Correção (verificação pedida pelo utilizador, 2026-09-13: "os grupos devem estar na
  // classificação. o calendário e resultados é para calendário e resultados"): as tabelas de
  // grupo (europaGroupTableHtml) apareciam sempre dentro do separador "Calendário & Resultados",
  // com o separador "Classificação" sempre vazio — ao contrário de qualquer outra competição do
  // jogo, onde a classificação e o calendário são sempre separadores distintos. Cada grupo já tem
  // o seu próprio calendário jornada-a-jornada (`grupo.fixtures`, gerado por
  // generateValidatedFixtures em 07g-europa.js, exatamente como uma liga normal) — só nunca tinha
  // sido usado para nada, porque o "Calendário & Resultados" mostrava sempre a tabela em vez do
  // calendário. europaGroupFixturesHtml reutiliza a mesma marcação (fixture-row/jornada-heading)
  // já usada em renderFixtures() para os campeonatos normais.
  function europaGroupFixturesHtml(grupo){
    return (grupo.fixtures||[]).map((round, idx)=>{
      const rows = round.map(fx=>{
        const isMe = fx.home===state.userTeamId || fx.away===state.userTeamId;
        const homeT = state.teams[fx.home], awayT = state.teams[fx.away];
        const score = fx.played ? `${fx.homeScore} – ${fx.awayScore}${fx.soWinner?' <span style="font-size:9px;color:var(--texto-mute);">(g.p.)</span>':''}` : "vs";
        return `<div class="fixture-row ${isMe?'me':''}">
          <div class="home"><button class="jr-team-link jr-home" data-team="${fx.home}">${homeT?homeT.name:'?'}</button></div><div class="vs">${score}</div><div class="away"><button class="jr-team-link jr-away" data-team="${fx.away}">${awayT?awayT.name:'?'}</button></div>
        </div>`;
      }).join("");
      return `<div class="jornada-heading">${grupo.nome} — Jornada ${idx+1}</div>${rows}`;
    }).join("");
  }
  function renderEuropaQualificacaoStandalone(){
    const ed = state.europa && state.europa.edicao, meta=document.getElementById("competitionViewMeta");
    if(meta) meta.textContent = "16 clubes em 4 grupos de 4 (todos-contra-todos a uma mão) · vencedor de cada grupo sobe à WSE Champions League, 2º/3º à WSE Cup, 4º à WSE Trophy";
    ["statsGrid","teamsBody"].forEach(id=>{ const el=document.getElementById(id); if(el) el.innerHTML=""; });
    const playoffTab=document.getElementById("tabPlayoff"); if(playoffTab) playoffTab.innerHTML='<p class="helptext">A Ronda de Qualificação não tem playoff próprio.</p>';
    const standingsBody = document.getElementById("standingsBody");
    const fixturesBody = document.getElementById("fixturesBody");
    const temGrupos = !!(ed && ed.qualificacao && ed.qualificacao.grupos.length);
    if(standingsBody){
      standingsBody.innerHTML = temGrupos
        ? ed.qualificacao.grupos.map(g=>europaGroupTableHtml(g)).join("")
        : '<p class="helptext">A Ronda de Qualificação desta época ainda não foi apurada.</p>';
    }
    if(fixturesBody){
      let html = '<p class="helptext">Alimenta as três provas europeias ao mesmo tempo. Os nomes a negrito são os jogos do teu clube.</p>';
      html += temGrupos
        ? ed.qualificacao.grupos.map(g=>europaGroupFixturesHtml(g)).join("")
        : '<p class="helptext">A Ronda de Qualificação desta época ainda não foi apurada.</p>';
      fixturesBody.innerHTML = html;
      europaAttachTeamLinks(fixturesBody);
    }
    document.querySelectorAll(".tab-btn").forEach(b=>b.classList.toggle("active", b.getAttribute("data-tab")==="tabFixtures"));
    document.querySelectorAll(".tab-content").forEach(t=>t.classList.toggle("active", t.id==="tabFixtures"));
  }
  const EUROPA_BRACKET_META = {
    champions: "12 clubes · 2 grupos de 6 (todos-contra-todos a duas mãos) seguidos de quartos/meias/final em campo neutro (Final a Oito, simplificada)",
    cup: "16 clubes · oitavos a duas mãos, quartos em casa de um dos dois, meias e final em Final a Quatro (campo neutro)",
    trophy: "11 clubes · os 5 melhores entram direto nos quartos, os restantes 6 disputam uma eliminatória preliminar · quartos/meias/final em campo neutro",
  };
  function renderEuropaBracketStandalone(compKey){
    const ed = state.europa && state.europa.edicao;
    const bracket = ed && ed[compKey];
    const meta = document.getElementById("competitionViewMeta");
    if(meta) meta.textContent = EUROPA_BRACKET_META[compKey];
    ["statsGrid","teamsBody"].forEach(id=>{ const el=document.getElementById(id); if(el) el.innerHTML=""; });
    const playoffTab=document.getElementById("tabPlayoff"); if(playoffTab) playoffTab.innerHTML=`<p class="helptext">A ${EUROPA_PRIZES[compKey]?EUROPA_PRIZES[compKey].label:compKey} não tem playoff próprio — é já, em si, uma competição de eliminatórias/grupos.</p>`;
    const standingsBody = document.getElementById("standingsBody");
    const fixturesBody = document.getElementById("fixturesBody");
    if(fixturesBody){
      let standingsHtml = "";
      let html = '<p class="helptext">Os nomes a negrito são os jogos do teu clube.</p>';
      if(bracket){
        if(bracket.grupos && bracket.grupos.length){
          // Nos grupos da WSE Champions League (6 clubes cada), só os 4 primeiros seguem para os
          // quartos — ver europaStartChampionsKnockout (07g-europa.js), que elimina pos>=4 (0-index).
          const advanceCount = compKey==="champions" ? 4 : 0;
          standingsHtml += bracket.grupos.map(g=>europaGroupTableHtml(g,{advance:advanceCount})).join("");
          if(advanceCount){
            standingsHtml += `<div class="standings-legend" style="margin-bottom:14px;">
              <div class="leg-item"><span class="leg-swatch" style="background:#3FA34D;"></span> 1º–${advanceCount}º de cada grupo · Apuramento para os quartos-de-final</div>
              <div class="leg-item"><span class="leg-swatch" style="background:var(--vermelho);"></span> Restantes · Eliminados da prova</div>
            </div>`;
          }
          html += bracket.grupos.map(g=>europaGroupFixturesHtml(g)).join("");
        }
        ["preliminar","oitavos","quartos","meias","final"].forEach(fase=>{
          const ties = bracket.jogos && bracket.jogos[fase];
          if(!ties || !ties.length) return;
          html += `<div class="eyebrow" style="margin:14px 0 6px;">${EUROPA_FASE_LABEL[fase]}</div>` + ties.map(europaTieHtml).join("");
        });
        if(bracket.fase==="concluida" && bracket.campeao){
          html = `<div class="info-banner" style="margin-bottom:8px;"><div style="font-size:13px;font-weight:700;color:var(--verde-ok);">🏆 Vencedor da ${EUROPA_PRIZES[compKey].label} ${ed.seasonLabel}: ${state.teams[bracket.campeao]?teamLinkHtml(bracket.campeao):'?'}</div></div>` + html;
        }
      } else {
        standingsHtml = `<p class="helptext">Ainda não apurada nesta época.</p>`;
        html += `<p class="helptext">Ainda não apurada nesta época.</p>`;
      }
      const historico = (state.europa&&state.europa.historico||[]).slice().sort((a,b)=>(b.epoca||0)-(a.epoca||0)).filter(e=>!ed||e.epoca!==ed.epoca);
      if(historico.length){
        const campoHist = compKey==="champions"?"campeaoChampions":compKey==="cup"?"campeaoCup":"campeaoTrophy";
        html += '<div class="eyebrow" style="margin:18px 0 6px;">Histórico de edições anteriores</div>' + historico.map(e=>{
          const vencedorId = e[campoHist], vencedorNome = vencedorId && state.teams[vencedorId] ? teamLinkHtml(vencedorId) : '?';
          return `<div class="eyebrow" style="margin:10px 0 4px;font-weight:400;">${e.seasonLabel||seasonLabel(e.epoca)} — 🏆 ${vencedorNome}</div>`;
        }).join("");
      }
      if(standingsBody) standingsBody.innerHTML = standingsHtml;
      fixturesBody.innerHTML = html;
      europaAttachTeamLinks(fixturesBody);
    }
    document.querySelectorAll(".tab-btn").forEach(b=>b.classList.toggle("active", b.getAttribute("data-tab")==="tabFixtures"));
    document.querySelectorAll(".tab-content").forEach(t=>t.classList.toggle("active", t.id==="tabFixtures"));
  }
  // Repovoa o seletor de país (Portugal / España / Italia) — opções estáticas, mas repovoar é
  // barato e evita duas fontes de verdade (o HTML deixa de ter as opções escritas à mão).
  function populateCompetitionViewCountrySelect(){
    const sel=document.getElementById("competitionViewCountrySelect"); if(!sel) return;
    sel.innerHTML = COMPETITION_VIEW_GROUPS.map(g=>`<option value="${g.pais}">${g.label}</option>`).join("");
  }
  // Repovoa o seletor de competição apenas com as competições do país indicado — chamado sempre
  // que o país muda (seleção manual ou reabertura do menu), nunca lista países misturados.
  function populateCompetitionViewSelectForCountry(pais){
    const sel=document.getElementById("competitionViewSelect"); if(!sel) return;
    const group = COMPETITION_VIEW_GROUPS.find(g=>g.pais===pais) || COMPETITION_VIEW_GROUPS[0];
    sel.innerHTML = group.competitions.map(c=>`<option value="${c.id}">${c.label}</option>`).join("");
  }
  const STANDINGS_LEGEND_DEFAULT_HTML = `
        <div class="leg-item"><span class="leg-swatch" style="background:#3FA34D;"></span> 1º–8º · Apuramento para o playoff</div>
        <div class="leg-item"><span class="leg-swatch" style="background:var(--vermelho);"></span> Últimos 3 lugares · Despromoção</div>`;
  function renderCompetitionView(){
    const VIRTUAL_COMPETITION_IDS = ["taca-portugal","supertaca","elite-cup","copa-del-rey","coppa-italia","supercopa-espana","supercoppa-italiana","europa-qualificacao","europa-champions","europa-cup","europa-trophy","selecoes-mundial","selecoes-europeu","selecoes-mundial-s19","selecoes-europeu-s19"];
    if(!state.viewedCompetitionId || (!VIRTUAL_COMPETITION_IDS.includes(state.viewedCompetitionId) && !state.competitions[state.viewedCompetitionId])) state.viewedCompetitionId=state.userCompetitionId;
    // Repõe sempre a legenda-padrão da classificação (promoção/playoff/despromoção) antes de
    // despachar para qualquer vista "standalone" — só a Seleções precisa de a substituir (é a
    // única standalone que mostra mesmo uma classificação real, ver renderSelecoesStandalone),
    // por isso é mais simples repor aqui uma vez do que cada standalone ter de o fazer.
    const standingsLegendEl = document.getElementById("standingsLegend");
    if(standingsLegendEl) standingsLegendEl.innerHTML = STANDINGS_LEGEND_DEFAULT_HTML;
    // Separador "Registos" (10b-registos.js): preenchido aqui, antes de qualquer "return" das vistas
    // standalone, para mostrar sempre o conteúdo certo (recordes da liga, ou o aviso nas taças).
    renderRegistosTab();
    // Correção (2026-09-09): passo "País" antes da competição, para nunca misturar Portugal com
    // OK Liga/Serie A1 no mesmo menu — a lista de competições apresentada é sempre repovoada de
    // acordo com o país correspondente ao viewedCompetitionId atual (que, quando o menu é aberto
    // de novo a partir da navegação principal, foi reposto para o país/competição do utilizador —
    // ver o reset de state.viewedCompetitionId no clique dos botões da hub-nav, 01-nucleo.js).
    populateCompetitionViewCountrySelect();
    const pais = competitionViewCountryForId(state.viewedCompetitionId);
    const countrySelect=document.getElementById("competitionViewCountrySelect"); if(countrySelect) countrySelect.value=pais;
    populateCompetitionViewSelectForCountry(pais);
    const select=document.getElementById("competitionViewSelect"); if(select) select.value=state.viewedCompetitionId;
    // Logótipo da competição (pedido do utilizador, 2026-09-25: o logo real do Campeonato Placard
    // "tem de aparecer na competição") — antes de qualquer "return" abaixo, para cobrir também as
    // competições "standalone" (Taça, Elite Cup, etc.), que por agora não têm logo definido.
    const compLogoEl = document.getElementById("competitionViewLogo");
    if(compLogoEl){
      const compLogoUrl = competitionLogoUrl(state.viewedCompetitionId);
      if(compLogoUrl){ compLogoEl.src = compLogoUrl; compLogoEl.classList.remove("hidden"); }
      else { compLogoEl.removeAttribute("src"); compLogoEl.classList.add("hidden"); }
    }
    if(state.viewedCompetitionId==="taca-portugal"){ renderTacaPortugalStandalone(); return; }
    if(state.viewedCompetitionId==="supertaca"){ renderSupertacaStandalone(); return; }
    if(state.viewedCompetitionId==="elite-cup"){ renderEliteCupStandalone(); return; }
    if(state.viewedCompetitionId==="copa-del-rey"){ renderNationalCupStandalone("copa-del-rey"); return; }
    if(state.viewedCompetitionId==="coppa-italia"){ renderNationalCupStandalone("coppa-italia"); return; }
    if(state.viewedCompetitionId==="supercopa-espana"){ renderSupercopaEspanaStandalone(); return; }
    if(state.viewedCompetitionId==="supercoppa-italiana"){ renderSupercoppaItalianaStandalone(); return; }
    if(state.viewedCompetitionId==="europa-qualificacao"){ renderEuropaQualificacaoStandalone(); return; }
    if(state.viewedCompetitionId==="europa-champions"){ renderEuropaBracketStandalone("champions"); return; }
    if(state.viewedCompetitionId==="europa-cup"){ renderEuropaBracketStandalone("cup"); return; }
    if(state.viewedCompetitionId==="europa-trophy"){ renderEuropaBracketStandalone("trophy"); return; }
    if(state.viewedCompetitionId==="selecoes-mundial"){ renderSelecoesStandalone("mundial"); return; }
    if(state.viewedCompetitionId==="selecoes-europeu"){ renderSelecoesStandalone("europeu"); return; }
    if(state.viewedCompetitionId==="selecoes-mundial-s19"){ renderSelecoesStandalone("mundial-s19"); return; }
    if(state.viewedCompetitionId==="selecoes-europeu-s19"){ renderSelecoesStandalone("europeu-s19"); return; }
    const comp=state.competitions[state.viewedCompetitionId],meta=document.getElementById("competitionViewMeta");
    if(meta&&comp) meta.textContent=`${comp.teamIds.length} clubes · ${comp.currentRound}/${comp.fixtures.length} jornadas processadas${comp.id===state.userCompetitionId?' · tua competição':''}`;
    renderStandings(); renderFixtures(); renderTeams(); renderStats();
    const playoffTab=document.getElementById("tabPlayoff");
    // Correção: a liguilha de promoção (e agora a final da 2ª Divisão) são eventos entre
    // equipas da 2ª Divisão, não do Placard — antes só apareciam quando se via especificamente
    // a competição do Placard, ficando invisíveis para quem gere um clube da 2ª Divisão (ou
    // está só a ver essa competição por curiosidade).
    if(playoffTab && comp && comp.divisionId==="3div") playoffTab.innerHTML='<p class="helptext">Esta competição não tem playoff. O 1.º classificado de cada zona sobe sempre; o 2.º disputa o CN 3.ª Divisão Apuramento Promoção (sobem os 2 primeiros). O CN 3.ª Divisão Apuramento Campeão decide o título nacional, sem promoção associada.</p>' + terceiraDivisaoApuramentoCard();
    else if(playoffTab && comp && comp.divisionId!=="placard") playoffTab.innerHTML='<p class="helptext">Esta competição não tem playoff. O 1.º classificado disputa o CN 2.ª Divisão Apuramento Campeão e o 2.º o CN 2.ª Divisão Apuramento Promoção.</p>' + promotionTieCard() + secondDivisionFinalCard();
    else renderPlayoffTab();
  }
  const competitionViewSelect=document.getElementById("competitionViewSelect");
  if(competitionViewSelect) competitionViewSelect.addEventListener("change",e=>{ state.viewedCompetitionId=e.target.value; renderCompetitionView(); });
  const competitionViewCountrySelect=document.getElementById("competitionViewCountrySelect");
  if(competitionViewCountrySelect) competitionViewCountrySelect.addEventListener("change",e=>{
    const group = COMPETITION_VIEW_GROUPS.find(g=>g.pais===e.target.value) || COMPETITION_VIEW_GROUPS[0];
    state.viewedCompetitionId = group.competitions[0].id;
    renderCompetitionView();
  });

  function renderStandings(){
    const body = document.getElementById("standingsBody");
    const viewId=displayedCompetitionId();
    const sorted = standingsForCompetition(viewId);
    const viewComp=state.competitions[viewId];
    const n = sorted.length;
    body.innerHTML = sorted.map((t, idx) => {
      const dg = t.stats.GM - t.stats.GS;
      const isMe = t.id === state.userTeamId;
      const pos = idx+1;
      const zone = PLAYOFF_DIVISION_CONFIG[viewComp.divisionId] && pos<=8 ? "zone-playoff" : pos>n-3 ? "zone-relegation" : "";
      return `<tr class="${isMe?'me':''} ${zone}">
        <td class="num">${pos}</td>
        <td class="teamcell"><span class="swatch" style="background:${clubDisplayColor(t)};"></span><button class="jr-team-link" data-team="${t.id}">${t.name}</button></td>
        <td class="num">${t.stats.J}</td><td class="num">${t.stats.V}</td><td class="num">${t.stats.E}</td><td class="num">${t.stats.D}</td>
        <td class="num">${t.stats.GM}</td><td class="num">${t.stats.GS}</td><td class="num">${dg>0?'+':''}${dg}</td>
        <td class="num"><b>${t.stats.Pts}</b></td>
      </tr>`;
    }).join("");
  }

  function renderFixtures(){
    const body = document.getElementById("fixturesBody");
    let html = "";
    const comp=state.competitions[displayedCompetitionId()];
    (comp?comp.fixtures:[]).forEach((round, idx) => {
      html += `<div class="jornada-heading">Jornada ${idx+1}${idx===(comp?comp.currentRound:-1) ? ' · próxima' : ''}</div>`;
      round.forEach(fx => {
        const isMe = fx.home===state.userTeamId || fx.away===state.userTeamId;
        const homeT = state.teams[fx.home], awayT = state.teams[fx.away];
        const score = fx.played ? `${fx.homeScore} – ${fx.awayScore}${fx.soWinner?' <span style="font-size:9px;color:var(--texto-mute);">(g.p.)</span>':''}` : "vs";
        html += `<div class="fixture-row ${isMe?'me':''}">
          <div class="home"><button class="jr-team-link jr-home" data-team="${fx.home}">${homeT.name}</button></div><div class="vs">${score}</div><div class="away"><button class="jr-team-link jr-away" data-team="${fx.away}">${awayT.name}</button></div>
        </div>`;
      });
    });
    body.innerHTML = html;
  }

  function renderTeams(){
    const body = document.getElementById("teamsBody");
    body.innerHTML = competitionTeams().map(t => {
      const gr = t.players.filter(p=>p.pos==="GR").length;
      const j = t.players.length - gr;
      const isMine = t.id === state.userTeamId;
      // Correção (pedido do utilizador: "saber à cabeça o OVR dos jogadores não me parece muito
      // lógico"): esta tabela mostrava sempre o OVR REAL de qualquer jogador de qualquer clube,
      // até de adversários nunca observados — contornava por completo o nevoeiro de scouting já
      // usado na ficha do jogador (visibleOverall). Passa a usar a mesma estimativa com nevoeiro
      // (visibleOverall já devolve o valor real para o nosso próprio clube, sem precisar de
      // distinguir aqui) — a ordenação segue o mesmo valor mostrado, para a ordem da lista também
      // não denunciar a qualidade real de quem ainda não foi observado.
      const rows = t.players.slice().sort((a,b)=>visibleOverall(b,t)-visibleOverall(a,t)).map(p => `
        <div class="fixture-row" style="grid-template-columns:24px 1fr 34px 40px 40px;font-size:12px;">
          <div>${p.num}</div>
          <div><button class="playername-btn" data-team="${t.id}" data-id="${p.id}">${playerNameHtml(p)}</button></div>
          <div style="text-align:center;">${p.age}</div>
          <div><span class="pos-badge ${p.pos==='GR'?'gr':'j'}">${linhaAbbrev(p)}</span></div>
          <div style="text-align:center;">${visibleOverall(p,t)}</div>
        </div>`).join("");
      return `<details class="team-block" data-team-id="${t.id}">
        <summary><span class="swatch" style="width:12px;height:12px;border-radius:3px;background:${clubDisplayColor(t)};display:inline-block;"></span>
          <button class="jr-team-link" data-team="${t.id}">${t.name}</button> <span style="font-weight:400;color:var(--texto-mute);font-size:11px;">(${t.players.length} jog. · ${gr} GR / ${j} jog. de campo) · <b>${t.reputacao}</b> · Treino: <b>${t.condicoesTreino}</b>${t.provisional?' <span class="provisional-tag">PROVISÓRIO</span>':''}${isMine?' · o teu clube':''}</span>
          ${!isMine ? `<button class="plantel-btn" data-team="${t.id}" style="margin-left:auto;">✎ Plantel</button>` : ''}
        </summary>
        <div class="team-block-body">${rows}</div>
      </details>`;
    }).join("");
    body.querySelectorAll(".plantel-btn").forEach(btn => {
      btn.addEventListener("click", (e) => { e.preventDefault(); openImportModal(btn.getAttribute("data-team")); });
    });
    body.querySelectorAll(".playername-btn").forEach(btn => {
      btn.addEventListener("click", () => openPlayerModal(btn.getAttribute("data-team"), btn.getAttribute("data-id")));
    });
  }

  function renderStats(){
    const allPlayers = [];
    competitionTeams().forEach(t => t.players.forEach(p => allPlayers.push({p, team:t})));
    const topScorers = allPlayers.slice().sort((a,b)=>b.p.season.golos-a.p.season.golos).slice(0,15);
    const topAssists = allPlayers.slice().sort((a,b)=>b.p.season.assistencias-a.p.season.assistencias).slice(0,15);
    const topMVP = allPlayers.slice().filter(e=>(e.p.season.mvp||0)>0).sort((a,b)=>(b.p.season.mvp||0)-(a.p.season.mvp||0) || b.p.season.golos-a.p.season.golos).slice(0,15);
    const goalkeepers = allPlayers.filter(e=>e.p.pos==="GR");
    const topPenaltis = goalkeepers.slice().filter(e=>(e.p.season.penaltisDefendidos||0)>0).sort((a,b)=>b.p.season.penaltisDefendidos-a.p.season.penaltisDefendidos).slice(0,15);
    const topLivresDiretos = goalkeepers.slice().filter(e=>(e.p.season.livresDiretosDefendidos||0)>0).sort((a,b)=>b.p.season.livresDiretosDefendidos-a.p.season.livresDiretosDefendidos).slice(0,15);
    const totalCartoes = e => (e.p.season.amarelos||0)+(e.p.season.azuis||0)+(e.p.season.vermelhos||0);
    const topCartoes = allPlayers.slice().filter(e=>totalCartoes(e)>0).sort((a,b)=>totalCartoes(b)-totalCartoes(a)).slice(0,15);
    function buildTable(list, statKey, label){
      return `<table class="stat-list"><thead><tr><th>#</th><th>Jogador</th><th>Equipa</th><th class="num">${label}</th></tr></thead>
      <tbody>${list.map((entry,idx)=>`<tr><td>${idx+1}</td><td>${escapeHtml(entry.p.name)}</td><td>${teamLinkHtml(entry.team.id)}</td><td class="num">${entry.p.season[statKey]}</td></tr>`).join("")}</tbody></table>`;
    }
    function buildCardsTable(list){
      return `<table class="stat-list"><thead><tr><th>#</th><th>Jogador</th><th>Equipa</th>
        <th class="num" style="color:#8a6d00;">🟨</th><th class="num" style="color:var(--azul-cartao);">🟦</th><th class="num" style="color:var(--vermelho);">🟥</th>
        ${''}<th class="num">Susp.</th></tr></thead>
      <tbody>${list.map((entry,idx)=>`<tr><td>${idx+1}</td><td>${escapeHtml(entry.p.name)}</td><td>${teamLinkHtml(entry.team.id)}</td>
        <td class="num">${entry.p.season.amarelos||0}</td><td class="num">${entry.p.season.azuis||0}</td><td class="num">${entry.p.season.vermelhos||0}</td>
        <td class="num">${(entry.p.suspensoJogos||0)>0?'🚫 '+entry.p.suspensoJogos:'—'}</td></tr>`).join("")}</tbody></table>`;
    }
    const GS_MIN_JOGOS = 5;
    const gkWithGames = goalkeepers.filter(e=>e.p.season.jogos>0);
    const gkQualified = gkWithGames.filter(e=>e.p.season.jogos>=GS_MIN_JOGOS)
      .sort((a,b)=>{
        const avgA = a.p.season.golosSofridos/a.p.season.jogos, avgB = b.p.season.golosSofridos/b.p.season.jogos;
        if(avgA!==avgB) return avgA-avgB;
        if(b.p.season.jogos!==a.p.season.jogos) return b.p.season.jogos-a.p.season.jogos;
        return a.p.season.golosSofridos-b.p.season.golosSofridos;
      });
    const gkUnqualified = gkWithGames.filter(e=>e.p.season.jogos<GS_MIN_JOGOS).sort((a,b)=>a.p.season.jogos-b.p.season.jogos);
    function buildGSTable(list){
      return `<table class="stat-list"><thead><tr><th>#</th><th>Guarda-Redes</th><th>Equipa</th><th class="num">J</th><th class="num">GS</th><th class="num">Média</th></tr></thead>
      <tbody>${list.map((entry,idx)=>`<tr><td>${idx+1}</td><td>${escapeHtml(entry.p.name)}</td><td><button class="jr-team-link" data-team="${entry.team.id}">${entry.team.name}</button></td>
        <td class="num">${entry.p.season.jogos}</td><td class="num">${entry.p.season.golosSofridos||0}</td><td class="num">${avgPt(entry.p.season.golosSofridos, entry.p.season.jogos)}</td></tr>`).join("")}</tbody></table>`;
    }
    document.getElementById("statsGrid").innerHTML = `
      <div><div class="eyebrow" style="margin-bottom:8px;">Melhores Marcadores</div>${buildTable(topScorers,"golos","Golos")}</div>
      <div><div class="eyebrow" style="margin-bottom:8px;">Melhores Assistências</div>${buildTable(topAssists,"assistencias","Assist.")}</div>
      <div><div class="eyebrow" style="margin-bottom:8px;">MVP da Competição</div>${topMVP.length ? buildTable(topMVP,"mvp","MVP") : '<p style="font-size:12px;color:var(--texto-mute);">Ainda sem prémios MVP registados.</p>'}</div>
      <div><div class="eyebrow" style="margin-bottom:8px;">Melhores Guarda-Redes — Penáltis Defendidos</div>${topPenaltis.length ? buildTable(topPenaltis,"penaltisDefendidos","Defend.") : '<p style="font-size:12px;color:var(--texto-mute);">Ainda sem penáltis defendidos esta época.</p>'}</div>
      <div><div class="eyebrow" style="margin-bottom:8px;">Melhores Guarda-Redes — Livres Diretos Defendidos</div>${topLivresDiretos.length ? buildTable(topLivresDiretos,"livresDiretosDefendidos","Defend.") : '<p style="font-size:12px;color:var(--texto-mute);">Ainda sem livres diretos defendidos esta época.</p>'}</div>
      <div style="grid-column:1/-1;"><div class="eyebrow" style="margin-bottom:8px;">Guarda-Redes: Golos Sofridos <span style="font-weight:400;color:var(--texto-mute);">(mínimo ${GS_MIN_JOGOS} jogos para a tabela principal)</span></div>
        ${gkQualified.length ? buildGSTable(gkQualified) : '<p style="font-size:12px;color:var(--texto-mute);">Ainda ninguém atingiu o mínimo de jogos esta época.</p>'}
        ${gkUnqualified.length ? `<div class="eyebrow" style="margin:10px 0 6px;">Menos de ${GS_MIN_JOGOS} jogos</div>${buildGSTable(gkUnqualified)}` : ''}
      </div>
      <div style="grid-column:1/-1;"><div class="eyebrow" style="margin-bottom:8px;">Disciplina — Cartões</div>${topCartoes.length ? buildCardsTable(topCartoes) : '<p style="font-size:12px;color:var(--texto-mute);">Ainda sem cartões registados esta época.</p>'}</div>
    `;
  }

  // =================================================================
  // Tabs
  // =================================================================
  document.querySelectorAll(".tab-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".tab-btn").forEach(b=>b.classList.toggle("active", b===btn));
      const target = btn.getAttribute("data-tab");
      document.querySelectorAll(".tab-content").forEach(c=>c.classList.toggle("active", c.id===target));
    });
  });

  // =================================================================
  // Master render + init
  // =================================================================
  function renderAll(){
    const club = myTeam();
    document.getElementById("myClubName").textContent = club.name;
    const myClubDotEl = document.getElementById("myClubDot");
    const myClubCrestUrl = clubCrestUrl(club.id);
    if(myClubCrestUrl){
      // Escudos reais (2026-09-25): clube do Placard com imagem oficial — substitui a badge de
      // iniciais+cor por um <img> real; ver clubCrestUrl em 01-nucleo.js.
      myClubDotEl.classList.add("has-crest");
      myClubDotEl.style.background = "";
      myClubDotEl.style.color = "";
      myClubDotEl.innerHTML = `<img src="${myClubCrestUrl}" alt="" class="crest-img">`;
    } else {
      myClubDotEl.classList.remove("has-crest");
      myClubDotEl.innerHTML = "";
      const myClubBg = clubDisplayColor(club);
      myClubDotEl.style.background = myClubBg;
      // Reskin visual (Fase 1): badge com iniciais do clube, legível sobre qualquer cor via
      // contrastText — só visível no tema novo (o CSS do tema actual mantém o texto invisível,
      // "#myClubDot" continua a ser só um círculo de cor, tal como sempre foi).
      myClubDotEl.textContent = clubBadgeInitials(club.name);
      myClubDotEl.style.color = clubTextColor(club, myClubBg);
    }
    document.getElementById("managerNameLbl").textContent = state.managerName || "";
    const cm3ManagerName = document.getElementById("cm3ManagerName");
    if(cm3ManagerName) cm3ManagerName.textContent = state.managerName || "Treinador";
    const homeFaltasLbl = document.getElementById("homeFaltasLabel");
    const awayFaltasLbl = document.getElementById("awayFaltasLabel");
    if(homeFaltasLbl) homeFaltasLbl.textContent = "Faltas de equipa — Casa";
    if(awayFaltasLbl) awayFaltasLbl.textContent = "Faltas de equipa — Fora";
    renderRoster(); renderScoreboard(); renderFeed();
    // Correção: chamava renderStandings/renderFixtures/renderTeams/renderStats/renderPlayoffTab
    // diretamente, o que sobrepunha sempre o separador Playoff com o conteúdo do Placard,
    // mesmo que a competição selecionada fosse outra — renderCompetitionView já faz o mesmo
    // conjunto de atualizações, mas escolhendo o conteúdo certo consoante a competição vista.
    renderCompetitionView();
    renderHubDate(); renderClubeView(); renderFinances();
    const historicoLbl = document.getElementById("historicoSeasonLabel");
    if(historicoLbl) historicoLbl.textContent = seasonLabel(state.season);
    // Indicador de e-mails por ler (2026-09-25): sincroniza aqui também, e não só em
    // pushNews/renderNews, para já aparecer correto na primeira vez que a interface desenha
    // depois de carregar uma gravação, antes de qualquer notícia nova chegar nesta sessão.
    updateEmailNavBadge();
  }

  // =================================================================
