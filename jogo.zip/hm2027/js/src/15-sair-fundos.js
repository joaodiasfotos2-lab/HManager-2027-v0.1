
// =====================================================================================================
// Sair do jogo + fundos rotativos (2026-10-12). Módulo autónomo (só mexe no DOM e na janela).
//  1. Botão "Sair" no menu inicial (sai logo) e na barra lateral do jogo (pergunta se queres guardar).
//     Desktop (Tauri): fecha a janela e a aplicação. Browser: tenta window.close() e, se o browser não
//     deixar, avisa que podes fechar o separador.
//  2. Fundo com as fotografias de hóquei (img/fundos/): duas camadas com transição suave; muda ao abrir
//     o jogo e só de vez em quando ao carregar em "Continuar" (de 5 em 5 a 9 cliques, ao acaso).
// =====================================================================================================
(function(){
  const T = window.__TAURI__ || null;
  const $ = id => document.getElementById(id);

  // ------------------------------------------------------------------ Sair
  function aviso(msg){
    const D = window.hm2027Desktop;
    if(D && D.ativo && D.ativo() && D.aviso) D.aviso(msg); else alert(msg);
  }
  async function fecharAplicacao(){
    if(T && T.window && T.window.getCurrentWindow){
      const w = T.window.getCurrentWindow();
      try{ await w.close(); return; }catch(e){}
      try{ await w.destroy(); return; }catch(e){}
    }
    try{ window.close(); }catch(e){}
    setTimeout(() => aviso("O browser não deixa o jogo fechar o separador. Podes fechá-lo agora."), 300);
  }
  function abrirConfirmacao(){ const o = $("sairOverlay"); if(o) o.classList.remove("hidden"); }
  function fecharConfirmacao(){ const o = $("sairOverlay"); if(o) o.classList.add("hidden"); }

  $("menuExitBtn")?.addEventListener("click", fecharAplicacao);
  $("exitBtn")?.addEventListener("click", abrirConfirmacao);
  $("sairCancelarBtn")?.addEventListener("click", fecharConfirmacao);
  $("sairSemGuardarBtn")?.addEventListener("click", () => { fecharConfirmacao(); fecharAplicacao(); });
  $("sairGuardarBtn")?.addEventListener("click", () => {
    fecharConfirmacao();
    if(typeof window.hm2027GuardarEDepois === "function") window.hm2027GuardarEDepois(fecharAplicacao);
    else fecharAplicacao();
  });
  $("sairOverlay")?.addEventListener("click", e => { if(e.target === $("sairOverlay")) fecharConfirmacao(); });
  document.addEventListener("keydown", e => {
    const o = $("sairOverlay");
    if(e.key === "Escape" && o && !o.classList.contains("hidden")){ e.stopPropagation(); fecharConfirmacao(); }
  }, true);
  window.hm2027Sair = { pedir: abrirConfirmacao, executar: fecharAplicacao };

  // ------------------------------------------------------------------ Fundos
  const FUNDOS = [
    { src: "img/fundos/baliza.jpg",       pos: "center 62%" },
    { src: "img/fundos/sticks.jpg",       pos: "center 55%" },
    { src: "img/fundos/guarda-redes.jpg", pos: "center 35%" },
    { src: "img/fundos/bola-stick.jpg",   pos: "center 60%" }
  ];
  const CHAVE = "hm2027_fundo";
  const host = $("hmFundo");
  if(!host) return;
  const camadas = host.querySelectorAll(".f");
  let atual = -1, frente = 0, cliques = 0, limite = 5 + Math.floor(Math.random() * 5);

  function proximoGuardado(){
    try{ const n = parseInt(localStorage.getItem(CHAVE), 10); if(n >= 0) return n % FUNDOS.length; }catch(e){}
    return Math.floor(Math.random() * FUNDOS.length);
  }
  function guardar(i){ try{ localStorage.setItem(CHAVE, String((i + 1) % FUNDOS.length)); }catch(e){} }

  function mostrar(i, imediato){
    i = ((i % FUNDOS.length) + FUNDOS.length) % FUNDOS.length;
    if(i === atual) return;
    const f = FUNDOS[i], img = new Image();
    const aplicar = () => {
      const tras = camadas[1 - frente], fr = camadas[frente];
      tras.style.backgroundImage = `url("${f.src}")`; tras.style.backgroundPosition = f.pos;
      if(imediato) tras.style.transition = "none";
      tras.classList.add("on"); fr.classList.remove("on");
      if(imediato){ void tras.offsetWidth; tras.style.transition = ""; }
      frente = 1 - frente; atual = i; guardar(i);
    };
    img.onload = aplicar; img.onerror = aplicar; img.src = f.src;   // só troca quando a imagem já carregou
  }
  function rodar(){ mostrar(atual + 1); }

  mostrar(proximoGuardado(), true);
  document.addEventListener("click", e => {
    if(!(e.target && e.target.closest && e.target.closest("#continuarBtn"))) return;
    if(++cliques >= limite){ cliques = 0; limite = 5 + Math.floor(Math.random() * 5); rodar(); }
  });
  window.hm2027Fundos = { mostrar, rodar, total: FUNDOS.length, atual: () => atual };
})();
